export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      account_notes: {
        Row: {
          account_id: string
          account_notes: string | null
          created_at: string
          id: string
          updated_at: string
          user_id: string
          vm_notes: string | null
        }
        Insert: {
          account_id: string
          account_notes?: string | null
          created_at?: string
          id?: string
          updated_at?: string
          user_id: string
          vm_notes?: string | null
        }
        Update: {
          account_id?: string
          account_notes?: string | null
          created_at?: string
          id?: string
          updated_at?: string
          user_id?: string
          vm_notes?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "account_notes_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "trading_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      economic_events: {
        Row: {
          actual: string | null
          created_at: string
          currency: string
          event_date: string
          event_name: string
          event_time: string
          forecast: string | null
          id: string
          impact: string
          previous: string | null
        }
        Insert: {
          actual?: string | null
          created_at?: string
          currency: string
          event_date: string
          event_name: string
          event_time: string
          forecast?: string | null
          id?: string
          impact: string
          previous?: string | null
        }
        Update: {
          actual?: string | null
          created_at?: string
          currency?: string
          event_date?: string
          event_name?: string
          event_time?: string
          forecast?: string | null
          id?: string
          impact?: string
          previous?: string | null
        }
        Relationships: []
      }
      exchange_rates: {
        Row: {
          base_currency: string
          id: string
          rate: number
          source: string | null
          target_currency: string
          updated_at: string | null
        }
        Insert: {
          base_currency?: string
          id?: string
          rate: number
          source?: string | null
          target_currency: string
          updated_at?: string | null
        }
        Update: {
          base_currency?: string
          id?: string
          rate?: number
          source?: string | null
          target_currency?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      forex_factory_events: {
        Row: {
          actual: string | null
          country: string
          created_at: string | null
          currency: string
          description: string | null
          event_date: string
          event_time: string
          ff_event_id: string | null
          forecast: string | null
          id: string
          impact: string | null
          last_updated: string | null
          previous: string | null
          source_url: string | null
          title: string
        }
        Insert: {
          actual?: string | null
          country: string
          created_at?: string | null
          currency: string
          description?: string | null
          event_date: string
          event_time: string
          ff_event_id?: string | null
          forecast?: string | null
          id?: string
          impact?: string | null
          last_updated?: string | null
          previous?: string | null
          source_url?: string | null
          title: string
        }
        Update: {
          actual?: string | null
          country?: string
          created_at?: string | null
          currency?: string
          description?: string | null
          event_date?: string
          event_time?: string
          ff_event_id?: string | null
          forecast?: string | null
          id?: string
          impact?: string | null
          last_updated?: string | null
          previous?: string | null
          source_url?: string | null
          title?: string
        }
        Relationships: []
      }
      open_positions: {
        Row: {
          account_id: string | null
          commission: number | null
          current_price: number | null
          id: string
          open_price: number | null
          open_time: string | null
          profit: number | null
          swap: number | null
          symbol: string
          ticket: number
          type: string
          updated_at: string | null
          volume: number | null
        }
        Insert: {
          account_id?: string | null
          commission?: number | null
          current_price?: number | null
          id?: string
          open_price?: number | null
          open_time?: string | null
          profit?: number | null
          swap?: number | null
          symbol: string
          ticket: number
          type: string
          updated_at?: string | null
          volume?: number | null
        }
        Update: {
          account_id?: string | null
          commission?: number | null
          current_price?: number | null
          id?: string
          open_price?: number | null
          open_time?: string | null
          profit?: number | null
          swap?: number | null
          symbol?: string
          ticket?: number
          type?: string
          updated_at?: string | null
          volume?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "open_positions_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "trading_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          auth_provider: Database["public"]["Enums"]["auth_provider"]
          created_at: string
          currency_display: string | null
          id: string
          language: string | null
          manager_id: string | null
          name: string
          provider_id: string | null
          role: Database["public"]["Enums"]["user_role"]
          timezone: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          auth_provider?: Database["public"]["Enums"]["auth_provider"]
          created_at?: string
          currency_display?: string | null
          id?: string
          language?: string | null
          manager_id?: string | null
          name: string
          provider_id?: string | null
          role?: Database["public"]["Enums"]["user_role"]
          timezone?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          auth_provider?: Database["public"]["Enums"]["auth_provider"]
          created_at?: string
          currency_display?: string | null
          id?: string
          language?: string | null
          manager_id?: string | null
          name?: string
          provider_id?: string | null
          role?: Database["public"]["Enums"]["user_role"]
          timezone?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      trade_history: {
        Row: {
          account_id: string | null
          close_price: number | null
          close_time: string | null
          commission: number | null
          created_at: string | null
          id: string
          open_price: number | null
          open_time: string | null
          profit: number | null
          swap: number | null
          symbol: string
          ticket: number
          type: string
          volume: number | null
        }
        Insert: {
          account_id?: string | null
          close_price?: number | null
          close_time?: string | null
          commission?: number | null
          created_at?: string | null
          id?: string
          open_price?: number | null
          open_time?: string | null
          profit?: number | null
          swap?: number | null
          symbol: string
          ticket: number
          type: string
          volume?: number | null
        }
        Update: {
          account_id?: string | null
          close_price?: number | null
          close_time?: string | null
          commission?: number | null
          created_at?: string | null
          id?: string
          open_price?: number | null
          open_time?: string | null
          profit?: number | null
          swap?: number | null
          symbol?: string
          ticket?: number
          type?: string
          volume?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "trade_history_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "trading_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      trades: {
        Row: {
          account_id: string
          close_price: number | null
          close_time: string | null
          created_at: string
          id: string
          open_price: number
          open_time: string
          profit: number | null
          symbol: string
          trade_type: Database["public"]["Enums"]["trade_type"]
          volume: number
        }
        Insert: {
          account_id: string
          close_price?: number | null
          close_time?: string | null
          created_at?: string
          id?: string
          open_price: number
          open_time: string
          profit?: number | null
          symbol: string
          trade_type: Database["public"]["Enums"]["trade_type"]
          volume: number
        }
        Update: {
          account_id?: string
          close_price?: number | null
          close_time?: string | null
          created_at?: string
          id?: string
          open_price?: number
          open_time?: string
          profit?: number | null
          symbol?: string
          trade_type?: Database["public"]["Enums"]["trade_type"]
          volume?: number
        }
        Relationships: [
          {
            foreignKeyName: "trades_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "trading_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      trading_accounts: {
        Row: {
          account_number: string
          active: boolean
          api_key: string | null
          api_key_created_at: string | null
          api_key_encrypted: boolean | null
          api_key_expires_at: string | null
          balance: number
          created_at: string
          currency: string
          equity: number
          id: string
          is_cent: boolean
          margin: number
          name: string
          platform: Database["public"]["Enums"]["account_platform"]
          profit: number
          server: string
          updated_at: string
          user_id: string
        }
        Insert: {
          account_number: string
          active?: boolean
          api_key?: string | null
          api_key_created_at?: string | null
          api_key_encrypted?: boolean | null
          api_key_expires_at?: string | null
          balance?: number
          created_at?: string
          currency?: string
          equity?: number
          id?: string
          is_cent?: boolean
          margin?: number
          name: string
          platform: Database["public"]["Enums"]["account_platform"]
          profit?: number
          server: string
          updated_at?: string
          user_id: string
        }
        Update: {
          account_number?: string
          active?: boolean
          api_key?: string | null
          api_key_created_at?: string | null
          api_key_encrypted?: boolean | null
          api_key_expires_at?: string | null
          balance?: number
          created_at?: string
          currency?: string
          equity?: number
          id?: string
          is_cent?: boolean
          margin?: number
          name?: string
          platform?: Database["public"]["Enums"]["account_platform"]
          profit?: number
          server?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      trading_updates: {
        Row: {
          account_id: string | null
          api_key: string
          balance: number | null
          created_at: string | null
          equity: number | null
          id: string
          last_update_source: string | null
          margin: number | null
          margin_free: number | null
          margin_level: number | null
          open_trades_count: number | null
          profit: number | null
        }
        Insert: {
          account_id?: string | null
          api_key: string
          balance?: number | null
          created_at?: string | null
          equity?: number | null
          id?: string
          last_update_source?: string | null
          margin?: number | null
          margin_free?: number | null
          margin_level?: number | null
          open_trades_count?: number | null
          profit?: number | null
        }
        Update: {
          account_id?: string | null
          api_key?: string
          balance?: number | null
          created_at?: string | null
          equity?: number | null
          id?: string
          last_update_source?: string | null
          margin?: number | null
          margin_free?: number | null
          margin_level?: number | null
          open_trades_count?: number | null
          profit?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "trading_updates_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "trading_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      authenticate_connector: {
        Args: {
          p_account_number: string
          p_investor_password: string
          p_user_id: string
        }
        Returns: Json
      }
      get_current_user_role: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_manager_id: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      is_manager: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      is_owner: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      rotate_api_key: {
        Args: { account_uuid: string }
        Returns: string
      }
    }
    Enums: {
      account_platform: "MT4" | "MT5"
      auth_provider: "email" | "google" | "apple"
      trade_type: "buy" | "sell"
      user_role: "client" | "manager" | "owner"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      account_platform: ["MT4", "MT5"],
      auth_provider: ["email", "google", "apple"],
      trade_type: ["buy", "sell"],
      user_role: ["client", "manager", "owner"],
    },
  },
} as const
