import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Building, Users, DollarSign, TrendingUp, UserCog, Target, BarChart3 } from 'lucide-react';
import { MetricCard } from '@/components/MetricCard';

interface ExecutiveData {
  totalManagers: number;
  totalClients: number;
  totalAccounts: number;
  totalAUM: number;
  totalRevenue: number;
  averageClientBalance: number;
  monthlyGrowth: number;
}

const Executive = () => {
  const { profile } = useAuth();
  const [executiveData, setExecutiveData] = useState<ExecutiveData | null>(null);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('30days');

  useEffect(() => {
    if (profile?.role === 'owner') {
      fetchExecutiveData();
    }
  }, [profile, period]);

  const fetchExecutiveData = async () => {
    try {
      setLoading(true);

      // Buscar todos os gerentes
      const { data: managers, error: managersError } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'manager');

      if (managersError) throw managersError;

      // Buscar todos os clientes
      const { data: clients, error: clientsError } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'client');

      if (clientsError) throw clientsError;

      // Buscar todas as contas de trading
      const { data: accounts, error: accountsError } = await supabase
        .from('trading_accounts')
        .select('*');

      if (accountsError) throw accountsError;

      // Calcular métricas
      const totalAUM = accounts.reduce((sum, acc) => sum + (acc.equity || 0), 0);
      const totalRevenue = accounts.reduce((sum, acc) => sum + (acc.profit || 0), 0) * 0.2; // 20% de fee
      const averageClientBalance = clients.length > 0 ? totalAUM / clients.length : 0;

      // Calcular crescimento mensal (simulado para demo)
      const monthlyGrowth = 12.5;

      setExecutiveData({
        totalManagers: managers.length,
        totalClients: clients.length,
        totalAccounts: accounts.length,
        totalAUM,
        totalRevenue,
        averageClientBalance,
        monthlyGrowth
      });

    } catch (error) {
      console.error('Erro ao buscar dados executivos:', error);
    } finally {
      setLoading(false);
    }
  };

  if (profile?.role !== 'owner') {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold text-foreground">Acesso Negado</h1>
        <p className="text-muted-foreground">Esta área é restrita a proprietários.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/4"></div>
          <div className="h-4 bg-muted rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Visão Executiva</h1>
          <p className="text-muted-foreground">Dashboard estratégico do negócio</p>
        </div>
        
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7days">7 dias</SelectItem>
            <SelectItem value="30days">30 dias</SelectItem>
            <SelectItem value="90days">90 dias</SelectItem>
            <SelectItem value="365days">1 ano</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="growth">Crescimento</TabsTrigger>
          <TabsTrigger value="team">Equipe</TabsTrigger>
          <TabsTrigger value="revenue">Receita</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* KPIs Principais */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            <MetricCard
              title="AUM Total"
              value={`$${executiveData?.totalAUM.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0.00'}`}
              change="+18.3%"
              icon={Building}
              trend="positive"
            />
            <MetricCard
              title="Receita Total"
              value={`$${executiveData?.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0.00'}`}
              change="+12.5%"
              icon={DollarSign}
              trend="positive"
            />
            <MetricCard
              title="Clientes Ativos"
              value={executiveData?.totalClients.toString() || '0'}
              change="+8"
              icon={Users}
              trend="positive"
            />
            <MetricCard
              title="Gerentes"
              value={executiveData?.totalManagers.toString() || '0'}
              change="+1"
              icon={UserCog}
              trend="positive"
            />
          </div>

          {/* Métricas Secundárias */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <MetricCard
              title="Total de Contas"
              value={executiveData?.totalAccounts.toString() || '0'}
              icon={Target}
              trend="neutral"
            />
            <MetricCard
              title="Balance Médio/Cliente"
              value={`$${executiveData?.averageClientBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0.00'}`}
              icon={BarChart3}
              trend="neutral"
            />
            <MetricCard
              title="Crescimento Mensal"
              value={`${executiveData?.monthlyGrowth.toFixed(1) || '0.0'}%`}
              change="+2.3%"
              icon={TrendingUp}
              trend="positive"
            />
          </div>

          {/* Gráficos Principais */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <Card className="bg-gradient-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Crescimento de AUM</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Gráfico de crescimento de AUM ao longo do tempo
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Distribuição de Receita</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Gráfico de pizza mostrando fonte de receitas
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="growth" className="space-y-6">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <Card className="bg-gradient-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Crescimento de Clientes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Gráfico de crescimento de clientes
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Taxa de Retenção</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Métricas de retenção de clientes
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="team" className="space-y-6">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <Card className="bg-gradient-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Performance por Gerente</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Ranking de performance dos gerentes
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Distribuição de Clientes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Como os clientes estão distribuídos entre gerentes
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-6">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <Card className="bg-gradient-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Receita por Período</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Gráfico de receita ao longo do tempo
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Projeção de Receita</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Projeções futuras baseadas em tendências
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Executive;