import React, { useState, useEffect } from 'react';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Globe, 
  Bell,
  Filter,
  RefreshCw,
  MapPin
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { format, parseISO, addDays, differenceInMinutes, addHours } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface EconomicEvent {
  id: string;
  event_date: string;
  event_time: string;
  currency: string;
  event_name: string;
  impact: 'low' | 'medium' | 'high';
  forecast?: string;
  previous?: string;
  actual?: string;
}

interface TimeZone {
  name: string;
  label: string;
  offset: number;
}

const timeZones: TimeZone[] = [
  { name: 'America/Sao_Paulo', label: '🇧🇷 Brasil', offset: -3 },
  { name: 'America/New_York', label: '🇺🇸 New York', offset: -5 },
  { name: 'Europe/London', label: '🇬🇧 Londres', offset: 0 },
  { name: 'Asia/Tokyo', label: '🇯🇵 Tóquio', offset: 9 },
  { name: 'Australia/Sydney', label: '🇦🇺 Sydney', offset: 11 }
];

const Calendar = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [events, setEvents] = useState<EconomicEvent[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedEvent, setSelectedEvent] = useState<EconomicEvent | null>(null);
  const [showEventDialog, setShowEventDialog] = useState(false);
  const [impactFilter, setImpactFilter] = useState<string>('all');
  const [currencyFilter, setCurrencyFilter] = useState<string>('all');
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    fetchEvents();
    
    // Update current time every minute
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);

    return () => clearInterval(timer);
  }, []);

  const fetchEvents = async () => {
    try {
      const { data, error } = await supabase
        .from('economic_events')
        .select('*')
        .gte('event_date', format(new Date(), 'yyyy-MM-dd'))
        .order('event_date', { ascending: true })
        .order('event_time', { ascending: true });

      if (error) throw error;
      setEvents((data || []) as EconomicEvent[]);
    } catch (error) {
      toast({
        title: "Erro ao carregar eventos",
        description: "Não foi possível carregar o calendário econômico.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getEventsForDate = (date: Date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return events.filter(event => {
      const matchesDate = event.event_date === dateStr;
      const matchesImpact = impactFilter === 'all' || event.impact === impactFilter;
      const matchesCurrency = currencyFilter === 'all' || event.currency === currencyFilter;
      return matchesDate && matchesImpact && matchesCurrency;
    });
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getImpactVariant = (impact: string): "default" | "secondary" | "destructive" | "outline" => {
    switch (impact) {
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'outline';
    }
  };

  const getTimeInTimezone = (date: string, time: string, timezone: TimeZone) => {
    const eventDateTime = parseISO(`${date}T${time}`);
    const adjustedTime = addHours(eventDateTime, timezone.offset + 3); // +3 because events are in GMT-3 (Brazil)
    return format(adjustedTime, 'HH:mm');
  };

  const getCountdownToEvent = (date: string, time: string) => {
    const eventDateTime = parseISO(`${date}T${time}`);
    const minutesUntil = differenceInMinutes(eventDateTime, currentTime);
    
    if (minutesUntil < 0) return 'Finalizado';
    if (minutesUntil < 60) return `${minutesUntil}m`;
    if (minutesUntil < 1440) return `${Math.floor(minutesUntil / 60)}h ${minutesUntil % 60}m`;
    return `${Math.floor(minutesUntil / 1440)}d ${Math.floor((minutesUntil % 1440) / 60)}h`;
  };

  const setNotification = (event: EconomicEvent) => {
    // In a real implementation, this would set up push notifications
    toast({
      title: "Notificação configurada",
      description: `Você será notificado sobre: ${event.event_name}`,
    });
  };

  const getCurrencies = () => {
    const currencies = [...new Set(events.map(event => event.currency))];
    return currencies.sort();
  };

  const hasEventsOnDate = (date: Date) => {
    return getEventsForDate(date).length > 0;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Calendário Econômico</h1>
          <p className="text-muted-foreground">Eventos econômicos importantes com múltiplos fusos horários</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <Button onClick={fetchEvents} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Atualizar
          </Button>
          
          <Select value={impactFilter} onValueChange={setImpactFilter}>
            <SelectTrigger className="w-[120px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todo Impacto</SelectItem>
              <SelectItem value="high">Alto Impacto</SelectItem>
              <SelectItem value="medium">Médio Impacto</SelectItem>
              <SelectItem value="low">Baixo Impacto</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={currencyFilter} onValueChange={setCurrencyFilter}>
            <SelectTrigger className="w-[100px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              {getCurrencies().map(currency => (
                <SelectItem key={currency} value={currency}>{currency}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* World Clocks */}
      <Card className="bg-gradient-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Fusos Horários Principais
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {timeZones.map((tz) => {
              const localTime = addHours(currentTime, tz.offset + 3); // +3 to convert from Brazil time
              return (
                <div key={tz.name} className="text-center p-3 rounded-lg bg-muted/20">
                  <div className="text-sm font-medium text-card-foreground mb-1">{tz.label}</div>
                  <div className="text-lg font-mono text-primary">
                    {format(localTime, 'HH:mm')}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    GMT{tz.offset >= 0 ? '+' : ''}{tz.offset}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Calendar */}
        <Card className="bg-gradient-card border-border xl:col-span-1">
          <CardHeader>
            <CardTitle className="text-card-foreground">Calendário</CardTitle>
          </CardHeader>
          <CardContent>
            <CalendarComponent
              mode="single"
              selected={selectedDate}
              onSelect={(date) => date && setSelectedDate(date)}
              modifiers={{
                hasEvents: (date) => hasEventsOnDate(date)
              }}
              modifiersStyles={{
                hasEvents: {
                  backgroundColor: 'hsl(var(--primary))',
                  color: 'hsl(var(--primary-foreground))',
                  fontWeight: 'bold'
                }
              }}
              className="rounded-md border pointer-events-auto"
            />
            
            <div className="mt-4 space-y-2">
              <div className="text-sm font-medium text-card-foreground">Legenda:</div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="w-3 h-3 rounded bg-primary"></div>
                <span>Dias com eventos</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Events List */}
        <Card className="bg-gradient-card border-border xl:col-span-2">
          <CardHeader>
            <CardTitle className="text-card-foreground">
              Eventos - {format(selectedDate, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {getEventsForDate(selectedDate).length === 0 ? (
                <div className="text-center py-8">
                  <CalendarIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Nenhum evento econômico para esta data.</p>
                </div>
              ) : (
                getEventsForDate(selectedDate).map((event) => (
                  <div 
                    key={event.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-muted/20 hover:bg-muted/30 cursor-pointer transition-colors"
                    onClick={() => {
                      setSelectedEvent(event);
                      setShowEventDialog(true);
                    }}
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className="flex flex-col items-center gap-1">
                        <div className="text-sm font-mono text-card-foreground">
                          {event.event_time.slice(0, 5)}
                        </div>
                        <Badge variant={getImpactVariant(event.impact)} className="text-xs">
                          {event.impact.toUpperCase()}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="font-mono">
                          {event.currency}
                        </Badge>
                        <div className={`w-2 h-2 rounded-full ${getImpactColor(event.impact)}`}></div>
                      </div>
                      
                      <div className="flex-1">
                        <div className="font-medium text-card-foreground">{event.event_name}</div>
                        {event.forecast && (
                          <div className="text-sm text-muted-foreground">
                            Previsão: {event.forecast} | Anterior: {event.previous}
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <div className="text-sm font-medium text-card-foreground">
                          {getCountdownToEvent(event.event_date, event.event_time)}
                        </div>
                        <div className="text-xs text-muted-foreground">restante</div>
                      </div>
                      
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          setNotification(event);
                        }}
                      >
                        <Bell className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Event Detail Dialog */}
      <Dialog open={showEventDialog} onOpenChange={setShowEventDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedEvent?.event_name}</DialogTitle>
          </DialogHeader>
          
          {selectedEvent && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-2">Informações Básicas</div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Moeda:</span>
                      <Badge variant="outline">{selectedEvent.currency}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Impacto:</span>
                      <Badge variant={getImpactVariant(selectedEvent.impact)}>
                        {selectedEvent.impact.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Data:</span>
                      <span className="text-sm font-mono">
                        {format(parseISO(selectedEvent.event_date), 'dd/MM/yyyy')}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-2">Dados Econômicos</div>
                  <div className="space-y-2">
                    {selectedEvent.forecast && (
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Previsão:</span>
                        <span className="text-sm font-mono">{selectedEvent.forecast}</span>
                      </div>
                    )}
                    {selectedEvent.previous && (
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Anterior:</span>
                        <span className="text-sm font-mono">{selectedEvent.previous}</span>
                      </div>
                    )}
                    {selectedEvent.actual && (
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Atual:</span>
                        <span className="text-sm font-mono font-bold">{selectedEvent.actual}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              <div>
                <div className="text-sm font-medium text-muted-foreground mb-3">Horários por Fuso</div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {timeZones.map((tz) => (
                    <div key={tz.name} className="flex items-center justify-between p-2 rounded bg-muted/20">
                      <span className="text-sm">{tz.label}</span>
                      <span className="text-sm font-mono">
                        {getTimeInTimezone(selectedEvent.event_date, selectedEvent.event_time, tz)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button
                  onClick={() => setNotification(selectedEvent)}
                  className="bg-gradient-primary"
                >
                  <Bell className="h-4 w-4 mr-2" />
                  Configurar Alerta
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Calendar;