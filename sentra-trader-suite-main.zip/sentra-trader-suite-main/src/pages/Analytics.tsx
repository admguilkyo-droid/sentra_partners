import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Target, 
  BarChart3,
  Filter,
  Calendar,
  Download,
  Calculator
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { DateRange } from 'react-day-picker';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { MetricCard } from '@/components/MetricCard';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

interface AnalyticsData {
  sharpeRatio: number;
  maxDrawdown: number;
  profitFactor: number;
  winRate: number;
  totalTrades: number;
  avgWin: number;
  avgLoss: number;
  largestWin: number;
  largestLoss: number;
  consecutiveWins: number;
  consecutiveLosses: number;
  expectedValue: number;
}

interface TradingAccount {
  id: string;
  name: string;
  platform: string;
  balance: number;
  currency: string;
  is_cent: boolean;
}

const Analytics = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [accounts, setAccounts] = useState<TradingAccount[]>([]);
  const [selectedAccount, setSelectedAccount] = useState<string>('all');
  const [selectedPeriod, setSelectedPeriod] = useState('30D');
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    sharpeRatio: 1.45,
    maxDrawdown: -8.2,
    profitFactor: 1.68,
    winRate: 64.5,
    totalTrades: 150,
    avgWin: 125.50,
    avgLoss: -89.30,
    largestWin: 850.00,
    largestLoss: -320.50,
    consecutiveWins: 8,
    consecutiveLosses: 4,
    expectedValue: 23.45
  });

  const performanceData = {
    labels: Array.from({ length: 30 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (29 - i));
      return format(date, 'dd/MM');
    }),
    datasets: [
      {
        label: 'Equity Curve',
        data: Array.from({ length: 30 }, () => Math.random() * 5000 + 95000),
        borderColor: 'hsl(var(--primary))',
        backgroundColor: 'hsla(var(--primary), 0.1)',
        borderWidth: 2,
        fill: true,
        tension: 0.4,
      },
      {
        label: 'Drawdown',
        data: Array.from({ length: 30 }, () => Math.random() * -2000),
        borderColor: 'hsl(var(--destructive))',
        backgroundColor: 'hsla(var(--destructive), 0.1)',
        borderWidth: 2,
        fill: true,
        tension: 0.4,
      }
    ],
  };

  const monthlyPerformance = [
    { month: 'Jan', profit: 2450.80, trades: 45, winRate: 68 },
    { month: 'Fev', profit: 1890.30, trades: 38, winRate: 63 },
    { month: 'Mar', profit: 3210.50, trades: 52, winRate: 71 },
    { month: 'Abr', profit: -890.20, trades: 29, winRate: 45 },
    { month: 'Mai', profit: 4350.90, trades: 61, winRate: 74 },
    { month: 'Jun', profit: 2190.40, trades: 43, winRate: 65 },
  ];

  useEffect(() => {
    if (user) {
      fetchAccounts();
    }
  }, [user]);

  const fetchAccounts = async () => {
    try {
      const { data, error } = await supabase
        .from('trading_accounts')
        .select('id, name, platform, balance, currency, is_cent')
        .eq('user_id', user?.id);

      if (error) throw error;
      setAccounts(data || []);
    } catch (error) {
      console.error('Error fetching accounts:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRiskLevel = (sharpe: number) => {
    if (sharpe > 1.5) return { level: 'Baixo', color: 'text-trading-positive' };
    if (sharpe > 1.0) return { level: 'Médio', color: 'text-amber-500' };
    return { level: 'Alto', color: 'text-trading-negative' };
  };

  const getDrawdownSeverity = (drawdown: number) => {
    const abs = Math.abs(drawdown);
    if (abs < 5) return { severity: 'Baixo', color: 'text-trading-positive' };
    if (abs < 15) return { severity: 'Moderado', color: 'text-amber-500' };
    return { severity: 'Alto', color: 'text-trading-negative' };
  };

  const getProfitFactorQuality = (factor: number) => {
    if (factor > 2.0) return { quality: 'Excelente', color: 'text-trading-positive' };
    if (factor > 1.5) return { quality: 'Bom', color: 'text-trading-positive' };
    if (factor > 1.0) return { quality: 'Aceitável', color: 'text-amber-500' };
    return { quality: 'Ruim', color: 'text-trading-negative' };
  };

  const exportData = () => {
    const csvData = monthlyPerformance.map(item => 
      `${item.month},${item.profit},${item.trades},${item.winRate}%`
    );
    
    const csvContent = 'Mês,Lucro,Trades,Win Rate\n' + csvData.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'analytics_report.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Analytics Avançado</h1>
          <p className="text-muted-foreground">Análise detalhada da performance de trading</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-[140px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7D">7 Dias</SelectItem>
              <SelectItem value="15D">15 Dias</SelectItem>
              <SelectItem value="30D">30 Dias</SelectItem>
              <SelectItem value="60D">60 Dias</SelectItem>
              <SelectItem value="90D">90 Dias</SelectItem>
              <SelectItem value="180D">180 Dias</SelectItem>
              <SelectItem value="1Y">1 Ano</SelectItem>
              <SelectItem value="custom">Personalizado</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedAccount} onValueChange={setSelectedAccount}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Selecionar conta" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as Contas</SelectItem>
              {accounts.map((account) => (
                <SelectItem key={account.id} value={account.id}>
                  {account.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {selectedPeriod === 'custom' && (
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-[280px] justify-start text-left font-normal">
                  <Calendar className="mr-2 h-4 w-4" />
                  {dateRange?.from ? (
                    dateRange.to ? (
                      <>
                        {format(dateRange.from, "LLL dd, y", { locale: ptBR })} -{" "}
                        {format(dateRange.to, "LLL dd, y", { locale: ptBR })}
                      </>
                    ) : (
                      format(dateRange.from, "LLL dd, y", { locale: ptBR })
                    )
                  ) : (
                    <span>Selecionar período</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  initialFocus
                  mode="range"
                  defaultMonth={dateRange?.from}
                  selected={dateRange}
                  onSelect={setDateRange}
                  numberOfMonths={2}
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          )}

          <Button onClick={exportData} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Advanced Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <Card className="bg-gradient-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Sharpe Ratio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-card-foreground">{analytics.sharpeRatio}</div>
              <Calculator className="h-5 w-5 text-primary" />
            </div>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="outline" className={getRiskLevel(analytics.sharpeRatio).color}>
                Risco {getRiskLevel(analytics.sharpeRatio).level}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Max Drawdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-card-foreground">{analytics.maxDrawdown}%</div>
              <TrendingDown className="h-5 w-5 text-destructive" />
            </div>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="outline" className={getDrawdownSeverity(analytics.maxDrawdown).color}>
                {getDrawdownSeverity(analytics.maxDrawdown).severity}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Profit Factor</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-card-foreground">{analytics.profitFactor}</div>
              <Target className="h-5 w-5 text-primary" />
            </div>
            <div className="flex items-center gap-2 mt-2">
              <Badge variant="outline" className={getProfitFactorQuality(analytics.profitFactor).color}>
                {getProfitFactorQuality(analytics.profitFactor).quality}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Expected Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-trading-positive">$+{analytics.expectedValue}</div>
              <TrendingUp className="h-5 w-5 text-trading-positive" />
            </div>
            <div className="text-sm text-muted-foreground mt-2">Por trade</div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Chart */}
      <Card className="bg-gradient-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground">Curva de Equity e Drawdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <Line 
              data={performanceData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    position: 'top' as const,
                    labels: {
                      color: 'hsl(var(--card-foreground))',
                    },
                  },
                },
                scales: {
                  x: {
                    ticks: {
                      color: 'hsl(var(--muted-foreground))',
                    },
                    grid: {
                      color: 'hsl(var(--border))',
                    },
                  },
                  y: {
                    ticks: {
                      color: 'hsl(var(--muted-foreground))',
                    },
                    grid: {
                      color: 'hsl(var(--border))',
                    },
                  },
                },
              }}
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Statistics Table */}
        <Card className="bg-gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-card-foreground">Estatísticas Detalhadas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-sm text-muted-foreground">Total de Trades</div>
                  <div className="text-lg font-semibold text-card-foreground">{analytics.totalTrades}</div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm text-muted-foreground">Win Rate</div>
                  <div className="text-lg font-semibold text-trading-positive">{analytics.winRate}%</div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-sm text-muted-foreground">Ganho Médio</div>
                  <div className="text-lg font-semibold text-trading-positive">$+{analytics.avgWin}</div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm text-muted-foreground">Perda Média</div>
                  <div className="text-lg font-semibold text-trading-negative">${analytics.avgLoss}</div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-sm text-muted-foreground">Maior Ganho</div>
                  <div className="text-lg font-semibold text-trading-positive">$+{analytics.largestWin}</div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm text-muted-foreground">Maior Perda</div>
                  <div className="text-lg font-semibold text-trading-negative">${analytics.largestLoss}</div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-sm text-muted-foreground">Vitórias Consecutivas</div>
                  <div className="text-lg font-semibold text-card-foreground">{analytics.consecutiveWins}</div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm text-muted-foreground">Perdas Consecutivas</div>
                  <div className="text-lg font-semibold text-card-foreground">{analytics.consecutiveLosses}</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Monthly Performance */}
        <Card className="bg-gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-card-foreground">Performance Mensal</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {monthlyPerformance.map((month) => (
                <div key={month.month} className="flex items-center justify-between p-3 rounded-lg bg-muted/20">
                  <div className="flex items-center gap-3">
                    <div className="text-sm font-medium text-card-foreground min-w-[40px]">
                      {month.month}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {month.trades} trades • {month.winRate}% win
                    </div>
                  </div>
                  <div className={`text-sm font-mono ${month.profit >= 0 ? 'text-trading-positive' : 'text-trading-negative'}`}>
                    {month.profit >= 0 ? '+' : ''}${month.profit.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Analytics;