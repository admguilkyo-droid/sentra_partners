import React, { useState, useEffect } from 'react';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Target,
  Filter,
  Calendar,
  Wallet,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { MetricCard } from '@/components/MetricCard';
import { EquityChart } from '@/components/EquityChart';
import { RecentTrades } from '@/components/RecentTrades';
import { Newsfeed } from '@/components/NewsFeed';
import ForexFactoryCalendar from '@/components/ForexFactoryCalendar';

// Mock data for dashboard (fallback)
const mockMetrics = {
  totalBalance: 125430.50,
  plToday: 2419.80,
  performance30d: 8.45,
  winRate: 68.2
};

const mockEquityData = [
  { date: '2025-08-13', value: 118250.30 },
  { date: '2025-08-14', value: 119850.75 },
  { date: '2025-08-15', value: 121240.60 },
  { date: '2025-08-16', value: 120890.45 },
  { date: '2025-08-17', value: 122360.80 },
  { date: '2025-08-18', value: 123890.25 },
  { date: '2025-08-19', value: 125430.50 }
];

const Dashboard = () => {
  const { user, profile } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState('30D');
  const [selectedAccount, setSelectedAccount] = useState('All Accounts');

  // Função para buscar dados reais das contas do usuário
  const fetchRealData = async () => {
    if (!user) return null;
    
    try {
      // Buscar dados reais das trading_accounts do usuário
      const { data: accounts, error: accountsError } = await supabase
        .from('trading_accounts')
        .select('id, balance, equity, profit')
        .eq('user_id', user.id);

      if (accountsError) {
        console.error('Erro ao buscar contas:', accountsError);
        return null;
      }

      // Calcular métricas reais
      const totalBalance = accounts.reduce((sum, acc) => sum + (acc.balance || 0), 0);
      const totalEquity = accounts.reduce((sum, acc) => sum + (acc.equity || 0), 0);
      const totalProfit = accounts.reduce((sum, acc) => sum + (acc.profit || 0), 0);

      // Buscar dados de equity dos últimos 7 dias (simulado por enquanto)
      const realEquityData = [
        { date: '2025-09-06', value: totalEquity * 0.92 },
        { date: '2025-09-07', value: totalEquity * 0.94 },
        { date: '2025-09-08', value: totalEquity * 0.96 },
        { date: '2025-09-09', value: totalEquity * 0.98 },
        { date: '2025-09-10', value: totalEquity * 0.99 },
        { date: '2025-09-11', value: totalEquity * 1.01 },
        { date: '2025-09-12', value: totalEquity }
      ];

      // Calcular win rate
      if (accounts.length > 0) {
        const { data: trades, error: tradesError } = await supabase
          .from('trades')
          .select('profit')
          .in('account_id', accounts.map(acc => acc.id))
          .not('close_time', 'is', null);

        let winRate = 68.2; // default
        if (!tradesError && trades.length > 0) {
          const winningTrades = trades.filter(t => (t.profit || 0) > 0);
          winRate = (winningTrades.length / trades.length) * 100;
        }

        return {
          metrics: {
            totalBalance,
            plToday: totalProfit,
            performance30d: totalBalance > 0 ? ((totalEquity - totalBalance) / totalBalance) * 100 : 0,
            winRate
          },
          equityData: realEquityData.length > 0 ? realEquityData : [{ date: '2025-09-12', value: totalEquity }]
        };
      }

      return null;
    } catch (error) {
      console.error('Erro ao buscar dados reais:', error);
      return null;
    }
  };

  const [dashboardData, setDashboardData] = useState<{
    metrics: typeof mockMetrics;
    equityData: typeof mockEquityData;
  }>({
    metrics: mockMetrics,
    equityData: mockEquityData
  });

  useEffect(() => {
    if (profile?.role === 'client') {
      fetchRealData().then(data => {
        if (data) {
          setDashboardData(data);
        } else {
          // Se não há dados reais, usar dados zerados para novos usuários
          setDashboardData({
            metrics: {
              totalBalance: 0,
              plToday: 0,
              performance30d: 0,
              winRate: 0
            },
            equityData: [{ date: '2025-09-12', value: 0 }]
          });
        }
      });
    }
  }, [user, profile]);

  const renderClientDashboard = () => (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Visão geral da sua performance de trading</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" className="gap-2">
            <Filter className="h-4 w-4" />
            Período: {selectedPeriod}
          </Button>
          <Button variant="outline" size="sm" className="gap-2">
            <Wallet className="h-4 w-4" />
            {selectedAccount}
          </Button>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <MetricCard
          title="Balance Total"
          value={`$${dashboardData.metrics.totalBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          icon={DollarSign}
          trend="neutral"
        />
        <MetricCard
          title="P&L Hoje"
          value={`$${dashboardData.metrics.plToday.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          change="+5.2%"
          icon={dashboardData.metrics.plToday > 0 ? TrendingUp : TrendingDown}
          trend={dashboardData.metrics.plToday > 0 ? "positive" : "negative"}
        />
        <MetricCard
          title="Performance 30d"
          value={`${dashboardData.metrics.performance30d.toFixed(2)}%`}
          change="+2.1%"
          icon={TrendingUp}
          trend="positive"
        />
        <MetricCard
          title="Win Rate"
          value={`${dashboardData.metrics.winRate.toFixed(1)}%`}
          change="+3.5%"
          icon={Target}
          trend="positive"
        />
      </div>

      {/* Charts and Tables Row */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <EquityChart data={dashboardData.equityData} />
        <RecentTrades />
      </div>

      {/* ForexFactory Calendar */}
      <ForexFactoryCalendar />

      {/* News Feed */}
      <Newsfeed />
    </div>
  );

  const renderManagerDashboard = () => (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Manager Dashboard</h1>
          <p className="text-muted-foreground">Visão geral dos clientes gerenciados</p>
        </div>
      </div>

      {/* Manager Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <MetricCard
          title="Total AUM"
          value="$2,450,380.50"
          icon={DollarSign}
          trend="neutral"
        />
        <MetricCard
          title="Clientes Ativos"
          value="24"
          change="+2"
          icon={TrendingUp}
          trend="positive"
        />
        <MetricCard
          title="P&L Consolidado"
          value="$15,240.80"
          change="+8.4%"
          icon={TrendingUp}
          trend="positive"
        />
        <MetricCard
          title="Performance Média"
          value="12.3%"
          change="+1.8%"
          icon={Target}
          trend="positive"
        />
      </div>

      <Card className="bg-gradient-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground">Clientes Top Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-sm font-medium">
                    {i}
                  </div>
                  <div>
                    <p className="font-medium text-card-foreground">Cliente {i}</p>
                    <p className="text-xs text-muted-foreground">MT5 Main Account</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-mono text-sm text-card-foreground">+{(15 - i * 2).toFixed(1)}%</p>
                  <p className="text-xs text-trading-positive">$+{(1250 * i).toLocaleString()}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderOwnerDashboard = () => (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Executive Dashboard</h1>
          <p className="text-muted-foreground">Visão estratégica do negócio</p>
        </div>
      </div>

      {/* Executive Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <MetricCard
          title="Receita Total"
          value="$485,240.80"
          change="+12.5%"
          icon={DollarSign}
          trend="positive"
        />
        <MetricCard
          title="Clientes Ativos"
          value="156"
          change="+8"
          icon={TrendingUp}
          trend="positive"
        />
        <MetricCard
          title="Gerentes"
          value="8"
          change="+1"
          icon={Target}
          trend="positive"
        />
        <MetricCard
          title="AUM Total"
          value="$15.2M"
          change="+18.3%"
          icon={TrendingUp}
          trend="positive"
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <Card className="bg-gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-card-foreground">Revenue Growth</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center text-muted-foreground">
              Revenue Chart (Chart.js implementation)
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-card border-border">
          <CardHeader>
            <CardTitle className="text-card-foreground">Top Managers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-sm font-medium">
                      M{i}
                    </div>
                    <div>
                      <p className="font-medium text-card-foreground">Manager {i}</p>
                      <p className="text-xs text-muted-foreground">{5 + i * 2} clientes</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-mono text-sm text-card-foreground">${(45 + i * 12).toFixed(1)}K</p>
                    <p className="text-xs text-trading-positive">+{(8 + i).toFixed(1)}%</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  // Render based on user role
  switch (profile?.role) {
    case 'manager':
      return renderManagerDashboard();
    case 'owner':
      return renderOwnerDashboard();
    default:
      return renderClientDashboard();
  }
};

export default Dashboard;