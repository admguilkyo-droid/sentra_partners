import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Search, Users, DollarSign, TrendingUp, UserCog, Building } from 'lucide-react';
import { MetricCard } from '@/components/MetricCard';

interface Manager {
  id: string;
  name: string;
  user_id: string;
  created_at: string;
  clientsCount?: number;
  totalAUM?: number;
  totalProfit?: number;
}

const Managers = () => {
  const { profile } = useAuth();
  const [managers, setManagers] = useState<Manager[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (profile?.role === 'owner') {
      fetchManagers();
    }
  }, [profile]);

  const fetchManagers = async () => {
    try {
      // Buscar todos os gerentes
      const { data: managerProfiles, error: profilesError } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'manager');

      if (profilesError) throw profilesError;

      // Para cada gerente, buscar dados dos clientes e contas
      const managersWithData = await Promise.all(
        managerProfiles.map(async (manager) => {
          // Buscar clientes deste gerente
          const { data: clients, error: clientsError } = await supabase
            .from('profiles')
            .select('user_id')
            .eq('manager_id', manager.id)
            .eq('role', 'client');

          if (clientsError) throw clientsError;

          if (clients.length === 0) {
            return {
              ...manager,
              clientsCount: 0,
              totalAUM: 0,
              totalProfit: 0
            };
          }

          // Buscar contas de trading de todos os clientes
          const clientUserIds = clients.map(c => c.user_id);
          const { data: accounts, error: accountsError } = await supabase
            .from('trading_accounts')
            .select('balance, equity, profit')
            .in('user_id', clientUserIds);

          if (accountsError) throw accountsError;

          const totalAUM = accounts.reduce((sum, acc) => sum + (acc.equity || 0), 0);
          const totalProfit = accounts.reduce((sum, acc) => sum + (acc.profit || 0), 0);

          return {
            ...manager,
            clientsCount: clients.length,
            totalAUM,
            totalProfit
          };
        })
      );

      setManagers(managersWithData);
    } catch (error) {
      console.error('Erro ao buscar gerentes:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredManagers = managers.filter(manager =>
    manager.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalMetrics = managers.reduce(
    (acc, manager) => ({
      totalManagers: acc.totalManagers + 1,
      totalClients: acc.totalClients + (manager.clientsCount || 0),
      totalAUM: acc.totalAUM + (manager.totalAUM || 0),
      totalProfit: acc.totalProfit + (manager.totalProfit || 0)
    }),
    { totalManagers: 0, totalClients: 0, totalAUM: 0, totalProfit: 0 }
  );

  if (profile?.role !== 'owner') {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold text-foreground">Acesso Negado</h1>
        <p className="text-muted-foreground">Esta área é restrita a proprietários.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/4"></div>
          <div className="h-4 bg-muted rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Gerenciar Gerentes</h1>
          <p className="text-muted-foreground">Supervisione a performance da sua equipe de gerentes</p>
        </div>
      </div>

      {/* Métricas Gerais */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <MetricCard
          title="Total de Gerentes"
          value={totalMetrics.totalManagers.toString()}
          icon={UserCog}
          trend="neutral"
        />
        <MetricCard
          title="Total de Clientes"
          value={totalMetrics.totalClients.toString()}
          icon={Users}
          trend="neutral"
        />
        <MetricCard
          title="AUM Total"
          value={`$${totalMetrics.totalAUM.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          icon={Building}
          trend="neutral"
        />
        <MetricCard
          title="Profit Total"
          value={`$${totalMetrics.totalProfit.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
          icon={TrendingUp}
          trend={totalMetrics.totalProfit >= 0 ? "positive" : "negative"}
        />
      </div>

      {/* Busca */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Buscar gerentes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Lista de Gerentes */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredManagers.map((manager) => (
          <Card key={manager.id} className="bg-gradient-card border-border">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-card-foreground text-lg">{manager.name}</CardTitle>
                <Badge variant="secondary" className="text-xs">
                  Gerente
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Clientes</p>
                  <p className="font-semibold text-card-foreground text-lg">
                    {manager.clientsCount || 0}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">AUM</p>
                  <p className="font-mono text-card-foreground">
                    ${manager.totalAUM?.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0.00'}
                  </p>
                </div>
              </div>
              
              <div className="pt-2 border-t border-border">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground text-sm">P&L Total</span>
                  <span className={`font-mono text-sm ${
                    (manager.totalProfit || 0) >= 0 ? 'text-trading-positive' : 'text-trading-negative'
                  }`}>
                    ${manager.totalProfit?.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0.00'}
                  </span>
                </div>
              </div>

              <div className="text-xs text-muted-foreground">
                Ativo desde {new Date(manager.created_at).toLocaleDateString('pt-BR')}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredManagers.length === 0 && !loading && (
        <Card className="bg-gradient-card border-border">
          <CardContent className="flex flex-col items-center justify-center py-8">
            <UserCog className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium text-card-foreground">Nenhum gerente encontrado</h3>
            <p className="text-muted-foreground text-center">
              {searchTerm ? 'Nenhum gerente corresponde à sua busca.' : 'Você ainda não possui gerentes cadastrados.'}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default Managers;