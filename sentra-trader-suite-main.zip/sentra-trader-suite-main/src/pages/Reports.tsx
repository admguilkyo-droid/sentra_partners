import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Download, TrendingUp, TrendingDown, DollarSign, Target } from 'lucide-react';
import { MetricCard } from '@/components/MetricCard';

interface ReportData {
  totalTrades: number;
  winRate: number;
  totalProfit: number;
  totalVolume: number;
  averageProfit: number;
  averageLoss: number;
  bestTrade: number;
  worstTrade: number;
}

const Reports = () => {
  const { profile } = useAuth();
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('30days');
  const [selectedAccount, setSelectedAccount] = useState('all');

  useEffect(() => {
    if (profile?.role === 'manager') {
      fetchReportData();
    }
  }, [profile, period, selectedAccount]);

  const fetchReportData = async () => {
    try {
      setLoading(true);
      
      // Calcular data baseada no período selecionado
      const now = new Date();
      let startDate = new Date();
      
      switch (period) {
        case '7days':
          startDate.setDate(now.getDate() - 7);
          break;
        case '30days':
          startDate.setDate(now.getDate() - 30);
          break;
        case '90days':
          startDate.setDate(now.getDate() - 90);
          break;
        case '365days':
          startDate.setFullYear(now.getFullYear() - 1);
          break;
        default:
          startDate.setDate(now.getDate() - 30);
      }

      // Buscar clientes do gerente
      const { data: clients, error: clientsError } = await supabase
        .from('profiles')
        .select('user_id')
        .eq('manager_id', profile?.id)
        .eq('role', 'client');

      if (clientsError) throw clientsError;

      if (clients.length === 0) {
        setReportData({
          totalTrades: 0,
          winRate: 0,
          totalProfit: 0,
          totalVolume: 0,
          averageProfit: 0,
          averageLoss: 0,
          bestTrade: 0,
          worstTrade: 0
        });
        return;
      }

      // Buscar contas de trading dos clientes
      const clientUserIds = clients.map(c => c.user_id);
      let query = supabase
        .from('trading_accounts')
        .select('id, balance, equity, profit')
        .in('user_id', clientUserIds);

      if (selectedAccount !== 'all') {
        query = query.eq('id', selectedAccount);
      }

      const { data: accounts, error: accountsError } = await query;
      if (accountsError) throw accountsError;

      if (accounts.length === 0) {
        setReportData({
          totalTrades: 0,
          winRate: 0,
          totalProfit: 0,
          totalVolume: 0,
          averageProfit: 0,
          averageLoss: 0,
          bestTrade: 0,
          worstTrade: 0
        });
        return;
      }

      const accountIds = accounts.map(acc => acc.id);

      // Buscar trades do período
      const { data: trades, error: tradesError } = await supabase
        .from('trades')
        .select('*')
        .in('account_id', accountIds)
        .gte('created_at', startDate.toISOString())
        .lte('created_at', now.toISOString())
        .not('close_time', 'is', null);

      if (tradesError) throw tradesError;

      // Calcular métricas
      const totalTrades = trades.length;
      const winningTrades = trades.filter(t => (t.profit || 0) > 0);
      const losingTrades = trades.filter(t => (t.profit || 0) < 0);
      
      const totalProfit = trades.reduce((sum, t) => sum + (t.profit || 0), 0);
      const totalVolume = trades.reduce((sum, t) => sum + (t.volume || 0), 0);
      
      const winRate = totalTrades > 0 ? (winningTrades.length / totalTrades) * 100 : 0;
      
      const averageProfit = winningTrades.length > 0 
        ? winningTrades.reduce((sum, t) => sum + (t.profit || 0), 0) / winningTrades.length 
        : 0;
      
      const averageLoss = losingTrades.length > 0 
        ? losingTrades.reduce((sum, t) => sum + (t.profit || 0), 0) / losingTrades.length 
        : 0;

      const bestTrade = trades.length > 0 
        ? Math.max(...trades.map(t => t.profit || 0)) 
        : 0;
      
      const worstTrade = trades.length > 0 
        ? Math.min(...trades.map(t => t.profit || 0)) 
        : 0;

      setReportData({
        totalTrades,
        winRate,
        totalProfit,
        totalVolume,
        averageProfit,
        averageLoss,
        bestTrade,
        worstTrade
      });

    } catch (error) {
      console.error('Erro ao buscar dados do relatório:', error);
    } finally {
      setLoading(false);
    }
  };

  if (profile?.role !== 'manager') {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold text-foreground">Acesso Negado</h1>
        <p className="text-muted-foreground">Esta área é restrita a gerentes.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/4"></div>
          <div className="h-4 bg-muted rounded w-1/2"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Relatórios</h1>
          <p className="text-muted-foreground">Análise detalhada da performance dos clientes</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">7 dias</SelectItem>
              <SelectItem value="30days">30 dias</SelectItem>
              <SelectItem value="90days">90 dias</SelectItem>
              <SelectItem value="365days">1 ano</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" size="sm" className="gap-2">
            <Download className="h-4 w-4" />
            Exportar
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="trades">Trades</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Métricas Principais */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            <MetricCard
              title="Total de Trades"
              value={reportData?.totalTrades.toString() || '0'}
              icon={Target}
              trend="neutral"
            />
            <MetricCard
              title="Win Rate"
              value={`${reportData?.winRate.toFixed(1) || '0.0'}%`}
              icon={TrendingUp}
              trend={reportData && reportData.winRate >= 50 ? "positive" : "negative"}
            />
            <MetricCard
              title="Profit Total"
              value={`$${reportData?.totalProfit.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0.00'}`}
              icon={DollarSign}
              trend={reportData && reportData.totalProfit >= 0 ? "positive" : "negative"}
            />
            <MetricCard
              title="Volume Total"
              value={reportData?.totalVolume.toFixed(2) || '0.00'}
              icon={TrendingUp}
              trend="neutral"
            />
          </div>

          {/* Métricas Detalhadas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gradient-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Análise de Profit/Loss</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-muted-foreground text-sm">Profit Médio</p>
                    <p className="text-trading-positive font-mono">
                      ${reportData?.averageProfit.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0.00'}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm">Loss Médio</p>
                    <p className="text-trading-negative font-mono">
                      ${reportData?.averageLoss.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0.00'}
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-muted-foreground text-sm">Melhor Trade</p>
                    <p className="text-trading-positive font-mono">
                      ${reportData?.bestTrade.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0.00'}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm">Pior Trade</p>
                    <p className="text-trading-negative font-mono">
                      ${reportData?.worstTrade.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) || '0.00'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Performance por Período</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-48 flex items-center justify-center text-muted-foreground">
                  Gráfico de Performance (Em breve)
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <Card className="bg-gradient-card border-border">
            <CardHeader>
              <CardTitle className="text-card-foreground">Análise de Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center text-muted-foreground">
                Gráficos de performance detalhada (Em desenvolvimento)
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trades" className="space-y-6">
          <Card className="bg-gradient-card border-border">
            <CardHeader>
              <CardTitle className="text-card-foreground">Histórico de Trades</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center text-muted-foreground">
                Tabela detalhada de trades (Em desenvolvimento)
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Reports;