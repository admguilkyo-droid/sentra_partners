import React, { useState, useEffect } from 'react';
import { 
  CreditCard, 
  Plus, 
  Download, 
  Edit, 
  MoreHorizontal,
  Activity,
  DollarSign,
  TrendingUp,
  StickyNote
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface TradingAccount {
  id: string;
  name: string;
  platform: 'MT4' | 'MT5';
  account_number: string;
  server: string;
  currency: string;
  is_cent: boolean;
  balance: number;
  equity: number;
  margin: number;
  profit: number;
  active: boolean;
  api_key?: string;
}

interface AccountNotes {
  vm_notes: string;
  account_notes: string;
}

const Accounts = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [accounts, setAccounts] = useState<TradingAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAccount, setSelectedAccount] = useState<TradingAccount | null>(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showNotesDialog, setShowNotesDialog] = useState(false);
  const [notes, setNotes] = useState<AccountNotes>({ vm_notes: '', account_notes: '' });
  
  // Form states
  const [formData, setFormData] = useState({
    name: '',
    platform: 'MT5' as 'MT4' | 'MT5',
    account_number: '',
    password: '',
    server: '',
    currency: 'USD',
    is_cent: false,
    is_demo: false,
    balance: 0
  });

  useEffect(() => {
    if (user) {
      fetchAccounts();
    }
  }, [user]);

  const fetchAccounts = async () => {
    try {
      const { data, error } = await supabase
        .from('trading_accounts')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setAccounts(data || []);
    } catch (error) {
      toast({
        title: "Erro ao carregar contas",
        description: "Não foi possível carregar suas contas de trading.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchNotes = async (accountId: string) => {
    try {
      const { data, error } = await supabase
        .from('account_notes')
        .select('*')
        .eq('account_id', accountId)
        .eq('user_id', user?.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      
      setNotes({
        vm_notes: data?.vm_notes || '',
        account_notes: data?.account_notes || ''
      });
    } catch (error) {
      console.error('Error fetching notes:', error);
    }
  };

  const saveNotes = async () => {
    if (!selectedAccount || !user) return;

    try {
      const { error } = await supabase
        .from('account_notes')
        .upsert({
          account_id: selectedAccount.id,
          user_id: user.id,
          vm_notes: notes.vm_notes,
          account_notes: notes.account_notes
        }, {
          onConflict: 'account_id,user_id'
        });

      if (error) throw error;

      toast({
        title: "Notas salvas",
        description: "Suas anotações foram salvas com sucesso.",
      });
      
      setShowNotesDialog(false);
    } catch (error) {
      toast({
        title: "Erro ao salvar notas",
        description: "Não foi possível salvar as anotações.",
        variant: "destructive",
      });
    }
  };

  const handleAddAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      // Generate a secure API key for the account
      const apiKey = `sk_${Date.now()}_${Math.random().toString(36).substr(2, 16)}`;
      
      const { error } = await supabase
        .from('trading_accounts')
        .insert({
          user_id: user.id,
          name: formData.name,
          platform: formData.platform,
          account_number: formData.account_number,
          server: formData.server,
          currency: formData.currency,
          is_cent: formData.is_cent,
          balance: formData.balance,
          api_key: apiKey
        });

      if (error) throw error;

      toast({
        title: "✅ Conta conectada com sucesso!",
        description: `Sua conta ${formData.platform} foi adicionada. Agora você pode gerar o conector personalizado.`,
      });

      setShowAddDialog(false);
      setFormData({
        name: '',
        platform: 'MT5',
        account_number: '',
        password: '',
        server: '',
        currency: 'USD',
        is_cent: false,
        is_demo: false,
        balance: 0
      });
      
      fetchAccounts();
    } catch (error: any) {
      console.error('Error adding account:', error);
      toast({
        title: "❌ Erro ao conectar conta",
        description: error.message || "Não foi possível adicionar a conta de trading.",
        variant: "destructive",
      });
    }
  };

  const generateConnector = async (account: TradingAccount) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast({
          title: "Erro de autenticação",
          description: "Você precisa estar logado para gerar conectores.",
          variant: "destructive",
        });
        return;
      }

      const response = await supabase.functions.invoke('generate-connector', {
        body: { 
          accountId: account.id, 
          platform: account.platform 
        },
        headers: {
          'Authorization': `Bearer ${session.access_token}`
        }
      });

      if (response.error) {
        throw new Error(response.error.message);
      }

      // Create and download file
      const blob = new Blob([response.data], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `SentraConnector_${account.platform}_${account.account_number}.${account.platform.toLowerCase()}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast({
        title: "Conector gerado com sucesso! 🎉",
        description: `Conector ${account.platform} personalizado baixado. Instale no seu MetaTrader para começar a sincronização.`,
      });
    } catch (error: any) {
      console.error('Error generating connector:', error);
      toast({
        title: "Erro ao gerar conector",
        description: error.message || "Não foi possível gerar o conector.",
        variant: "destructive",
      });
    }
  };

  const formatBalance = (amount: number, currency: string, isCent: boolean) => {
    const value = isCent ? amount / 100 : amount;
    const symbol = currency === 'USD' ? '$' : currency === 'EUR' ? '€' : currency;
    return `${symbol}${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
  };

  const openNotesDialog = (account: TradingAccount) => {
    setSelectedAccount(account);
    fetchNotes(account.id);
    setShowNotesDialog(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Contas de Trading</h1>
          <p className="text-muted-foreground">Gerencie suas contas e conectores MetaTrader</p>
        </div>
        
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-primary hover:opacity-90">
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Conta
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                🔗 Conectar Nova Conta de Trading
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddAccount} className="space-y-6">
              {/* Informações Básicas */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-foreground flex items-center gap-2">
                  📊 Informações da Conta
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Nome da Conta *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      placeholder="Ex: Conta Principal, Conta Demo"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="platform">Plataforma *</Label>
                    <Select value={formData.platform} onValueChange={(value: 'MT4' | 'MT5') => setFormData({...formData, platform: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="MT4">MetaTrader 4</SelectItem>
                        <SelectItem value="MT5">MetaTrader 5</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="currency">Moeda da Conta</Label>
                  <Select value={formData.currency} onValueChange={(value) => setFormData({...formData, currency: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">🇺🇸 USD - Dólar Americano</SelectItem>
                      <SelectItem value="EUR">🇪🇺 EUR - Euro</SelectItem>
                      <SelectItem value="GBP">🇬🇧 GBP - Libra Esterlina</SelectItem>
                      <SelectItem value="BRL">🇧🇷 BRL - Real Brasileiro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Credenciais do MetaTrader */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-foreground flex items-center gap-2">
                  🔐 Credenciais do MetaTrader
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="account_number">Login da Conta *</Label>
                    <Input
                      id="account_number"
                      value={formData.account_number}
                      onChange={(e) => setFormData({...formData, account_number: e.target.value})}
                      placeholder="Ex: 12345678"
                      pattern="[0-9]+"
                      title="Apenas números"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="password">Senha *</Label>
                    <Input
                      id="password"
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData({...formData, password: e.target.value})}
                      placeholder="Senha de Investidor ou Principal"
                      minLength={6}
                      required
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      💡 Recomendamos usar a senha de investidor (somente leitura)
                    </p>
                  </div>
                </div>

                <div>
                  <Label htmlFor="server">Servidor do Broker *</Label>
                  <Input
                    id="server"
                    value={formData.server}
                    onChange={(e) => setFormData({...formData, server: e.target.value})}
                    placeholder="Ex: ICMarkets-Demo, XM-Real"
                    required
                  />
                </div>
              </div>

              {/* Configurações */}
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-foreground flex items-center gap-2">
                  ⚙️ Configurações
                </h4>
                <div className="grid grid-cols-2 gap-6">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="is_demo"
                      checked={formData.is_demo}
                      onChange={(e) => setFormData({...formData, is_demo: e.target.checked})}
                      className="rounded border-border"
                    />
                    <Label htmlFor="is_demo">Conta Demonstração</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="is_cent"
                      checked={formData.is_cent}
                      onChange={(e) => setFormData({...formData, is_cent: e.target.checked})}
                      className="rounded border-border"
                    />
                    <Label htmlFor="is_cent">Conta Centavos</Label>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  ℹ️ Contas centavos têm valores divididos por 100
                </p>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                  Cancelar
                </Button>
                <Button type="submit" className="bg-gradient-primary hover:opacity-90">
                  💾 Salvar e Conectar
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {accounts.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <CreditCard className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold text-card-foreground mb-2">Nenhuma conta encontrada</h3>
            <p className="text-muted-foreground text-center mb-4">
              Comece adicionando sua primeira conta de trading para monitorar sua performance.
            </p>
            <Button onClick={() => setShowAddDialog(true)} className="bg-gradient-primary">
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Primeira Conta
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {accounts.map((account) => (
            <Card key={account.id} className="bg-gradient-card border-border">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/10">
                      <Activity className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-base text-card-foreground">{account.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        {account.platform} • {account.account_number}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Badge variant={account.active ? "default" : "secondary"}>
                      {account.active ? "Ativa" : "Inativa"}
                    </Badge>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => openNotesDialog(account)}>
                          <StickyNote className="h-4 w-4 mr-2" />
                          Notas da Conta
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => generateConnector(account)}
                          className="text-primary"
                        >
                          <Download className="h-4 w-4 mr-2" />
                          📥 Gerar Conector {account.platform}
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Login:</span>
                    <span className="font-mono text-xs">{account.account_number}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Servidor:</span>
                    <span className="font-mono text-xs truncate">{account.server}</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Balance</span>
                    <span className="font-mono text-sm font-medium">
                      {formatBalance(account.balance, account.currency, account.is_cent)}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Equity</span>
                    <span className="font-mono text-sm">
                      {formatBalance(account.equity, account.currency, account.is_cent)}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">P&L</span>
                    <span className={`font-mono text-sm ${
                      account.profit >= 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {account.profit >= 0 ? '+' : ''}{formatBalance(account.profit, account.currency, account.is_cent)}
                    </span>
                  </div>
                </div>

                {/* Connector Section */}
                <div className="pt-3 border-t border-border">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                      📥 Conector de Sincronização
                    </h5>
                  </div>
                  
                  <Button
                    onClick={() => generateConnector(account)}
                    variant="outline"
                    size="sm"
                    className="w-full bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20 hover:from-primary/20 hover:to-primary/10"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Baixar Conector {account.platform}
                  </Button>
                  
                  <p className="text-xs text-muted-foreground mt-2 text-center">
                    💡 Instale no MetaTrader para sincronização automática
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Notes Dialog */}
      <Dialog open={showNotesDialog} onOpenChange={setShowNotesDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Notas da Conta: {selectedAccount?.name}</DialogTitle>
          </DialogHeader>
          
          <Tabs defaultValue="vm" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="vm">VM</TabsTrigger>
              <TabsTrigger value="account">Conta</TabsTrigger>
            </TabsList>
            
            <TabsContent value="vm" className="space-y-4">
              <div>
                <Label htmlFor="vm-notes">Anotações da VM</Label>
                <Textarea
                  id="vm-notes"
                  placeholder="Anotações sobre a máquina virtual, configurações, etc..."
                  value={notes.vm_notes}
                  onChange={(e) => setNotes({...notes, vm_notes: e.target.value})}
                  className="min-h-[200px]"
                />
              </div>
            </TabsContent>
            
            <TabsContent value="account" className="space-y-4">
              <div>
                <Label htmlFor="account-notes">Anotações da Conta</Label>
                <Textarea
                  id="account-notes"
                  placeholder="Anotações sobre estratégias, performance, observações..."
                  value={notes.account_notes}
                  onChange={(e) => setNotes({...notes, account_notes: e.target.value})}
                  className="min-h-[200px]"
                />
              </div>
            </TabsContent>
          </Tabs>
          
          <DialogFooter>
            <Button onClick={saveNotes} className="bg-gradient-primary">
              Salvar Notas
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Accounts;