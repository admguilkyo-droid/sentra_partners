import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { UserPlus, Mail, Trash2, Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Invitation {
  id: string;
  email: string;
  role: string;
  invited_by: string;
  created_at: string;
  status: 'pending' | 'accepted' | 'expired';
}

const InviteUsers = () => {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    role: 'client' as 'client' | 'manager',
    managerId: ''
  });

  useEffect(() => {
    if (profile?.role === 'owner' || profile?.role === 'manager') {
      fetchInvitations();
    }
  }, [profile]);

  const fetchInvitations = async () => {
    try {
      // Note: This would need a table for invitations in the actual implementation
      // For now, we'll show a placeholder
      setInvitations([]);
    } catch (error) {
      console.error('Erro ao buscar convites:', error);
    }
  };

  const handleInviteUser = async () => {
    if (!formData.email || !formData.role) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    
    try {
      // Create a temporary password for the user
      const tempPassword = Math.random().toString(36).slice(-8) + 'A1!';
      
      // Send invitation email using Supabase Auth Admin API
      const { data, error } = await supabase.auth.admin.createUser({
        email: formData.email,
        password: tempPassword,
        email_confirm: true,
        user_metadata: {
          invited_by: profile?.user_id,
          role: formData.role,
          manager_id: formData.role === 'client' ? formData.managerId : undefined,
          temporary_password: true
        }
      });

      if (error) {
        throw error;
      }

      // Create profile for the user
      const profileData: any = {
        user_id: data.user.id,
        name: formData.email.split('@')[0], // Use email prefix as default name
        role: formData.role,
      };

      // If creating a client for a manager, set manager_id
      if (formData.role === 'client' && profile?.role === 'manager') {
        profileData.manager_id = profile.id;
      } else if (formData.role === 'client' && formData.managerId) {
        profileData.manager_id = formData.managerId;
      }

      const { error: profileError } = await supabase
        .from('profiles')
        .insert(profileData);

      if (profileError) {
        throw profileError;
      }

      toast({
        title: "Convite enviado!",
        description: `Usuário convidado com sucesso. Senha temporária: ${tempPassword}`,
      });

      setFormData({ email: '', role: 'client', managerId: '' });
      setIsDialogOpen(false);
      fetchInvitations();

    } catch (error: any) {
      console.error('Erro ao convidar usuário:', error);
      toast({
        title: "Erro ao enviar convite",
        description: error.message || "Ocorreu um erro inesperado.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getManagerOptions = async () => {
    if (profile?.role !== 'owner') return [];
    
    const { data: managers } = await supabase
      .from('profiles')
      .select('id, name')
      .eq('role', 'manager');
    
    return managers || [];
  };

  const [managers, setManagers] = useState<Array<{id: string, name: string}>>([]);

  useEffect(() => {
    if (profile?.role === 'owner') {
      getManagerOptions().then(setManagers);
    }
  }, [profile]);

  if (profile?.role !== 'owner' && profile?.role !== 'manager') {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold text-foreground">Acesso Negado</h1>
        <p className="text-muted-foreground">Esta área é restrita a gerentes e proprietários.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Convidar Usuários</h1>
          <p className="text-muted-foreground">
            {profile?.role === 'owner' 
              ? 'Convide gerentes e clientes para a plataforma'
              : 'Convide clientes para gerenciar'
            }
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <UserPlus className="h-4 w-4" />
              Convidar Usuário
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Convidar Novo Usuário</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="usuario@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                />
              </div>
              
              <div>
                <Label htmlFor="role">Função</Label>
                <Select 
                  value={formData.role} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, role: value as 'client' | 'manager' }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="client">Cliente</SelectItem>
                    {profile?.role === 'owner' && (
                      <SelectItem value="manager">Gerente</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>

              {formData.role === 'client' && profile?.role === 'owner' && managers.length > 0 && (
                <div>
                  <Label htmlFor="manager">Gerente Responsável</Label>
                  <Select 
                    value={formData.managerId} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, managerId: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione um gerente" />
                    </SelectTrigger>
                    <SelectContent>
                      {managers.map(manager => (
                        <SelectItem key={manager.id} value={manager.id}>
                          {manager.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleInviteUser} disabled={loading} className="gap-2">
                  <Send className="h-4 w-4" />
                  {loading ? 'Enviando...' : 'Enviar Convite'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Lista de Convites */}
      <Card className="bg-gradient-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Convites Enviados
          </CardTitle>
        </CardHeader>
        <CardContent>
          {invitations.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <UserPlus className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Nenhum convite enviado ainda.</p>
              <p className="text-sm">Clique em "Convidar Usuário" para começar.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {invitations.map((invitation) => (
                <div key={invitation.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div>
                      <p className="font-medium text-card-foreground">{invitation.email}</p>
                      <p className="text-sm text-muted-foreground">
                        {invitation.role} • Enviado em {new Date(invitation.created_at).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={invitation.status === 'pending' ? 'default' : 'secondary'}>
                      {invitation.status === 'pending' && 'Pendente'}
                      {invitation.status === 'accepted' && 'Aceito'}
                      {invitation.status === 'expired' && 'Expirado'}
                    </Badge>
                    <Button variant="ghost" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Instruções */}
      <Card className="bg-gradient-card border-border">
        <CardHeader>
          <CardTitle className="text-card-foreground">Como funciona</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• Ao convidar um usuário, ele receberá uma senha temporária</p>
          <p>• O usuário deve fazer login e alterar a senha no primeiro acesso</p>
          <p>• Gerentes podem convidar apenas clientes</p>
          <p>• Proprietários podem convidar gerentes e clientes</p>
          <p>• Clientes são automaticamente atribuídos ao gerente que os convidou</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default InviteUsers;