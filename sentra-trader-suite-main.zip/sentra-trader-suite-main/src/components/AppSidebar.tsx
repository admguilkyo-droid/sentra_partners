import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Wallet,
  TrendingUp,
  Calendar,
  Settings,
  Users,
  FileText,
  BarChart3,
  Building,
  UserPlus
} from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from '@/components/ui/sidebar';
import { useAuth } from '@/contexts/AuthContext';

const AppSidebar = () => {
  const { state } = useSidebar();
  const { profile } = useAuth();
  const location = useLocation();
  const isCollapsed = state === "collapsed";

  const getNavItems = () => {
    const commonItems = [
      { title: 'Dashboard', url: '/dashboard', icon: LayoutDashboard },
    ];

    switch (profile?.role) {
      case 'client':
        return [
          ...commonItems,
          { title: 'Contas', url: '/accounts', icon: Wallet },
          { title: 'Analytics', url: '/analytics', icon: TrendingUp },
          { title: 'Calendário', url: '/calendar', icon: Calendar },
          { title: 'Configurações', url: '/settings', icon: Settings },
        ];
      case 'manager':
        return [
          ...commonItems,
          { title: 'Clientes', url: '/clients', icon: Users },
          { title: 'Convidar Usuários', url: '/invite', icon: UserPlus },
          { title: 'Relatórios', url: '/reports', icon: FileText },
          { title: 'Analytics', url: '/analytics', icon: TrendingUp },
          { title: 'Configurações', url: '/settings', icon: Settings },
        ];
      case 'owner':
        return [
          ...commonItems,
          { title: 'Visão Executiva', url: '/executive', icon: Building },
          { title: 'Gerentes', url: '/managers', icon: Users },
          { title: 'Convidar Usuários', url: '/invite', icon: UserPlus },
          { title: 'Analytics', url: '/analytics', icon: BarChart3 },
          { title: 'Configurações', url: '/settings', icon: Settings },
        ];
      default:
        return commonItems;
    }
  };

  const navItems = getNavItems();

  const getNavClassName = ({ isActive }: { isActive: boolean }) =>
    isActive 
      ? "bg-primary/10 text-primary border-r-2 border-primary font-medium" 
      : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground";

  return (
    <Sidebar collapsible="icon">
      <SidebarContent className="bg-sidebar border-r border-sidebar-border">
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground/70 text-xs uppercase tracking-wider px-4 py-2">
            {!isCollapsed && 'Navegação'}
          </SidebarGroupLabel>
          
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink 
                      to={item.url} 
                      end={item.url === '/dashboard'}
                      className={getNavClassName}
                    >
                      <item.icon className="h-5 w-5 flex-shrink-0" />
                      {!isCollapsed && <span className="ml-3 truncate">{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Role indicator */}
        {!isCollapsed && (
          <div className="mt-auto p-4 border-t border-sidebar-border">
            <div className="bg-sidebar-accent rounded-lg p-3">
              <div className="text-xs text-sidebar-accent-foreground/70 uppercase tracking-wider">
                Nível de Acesso
              </div>
              <div className="text-sm font-medium text-sidebar-accent-foreground capitalize mt-1">
                {profile?.role === 'client' && 'Cliente'}
                {profile?.role === 'manager' && 'Gerente'}
                {profile?.role === 'owner' && 'Proprietário'}
              </div>
            </div>
          </div>
        )}
      </SidebarContent>
    </Sidebar>
  );
};

export { AppSidebar };