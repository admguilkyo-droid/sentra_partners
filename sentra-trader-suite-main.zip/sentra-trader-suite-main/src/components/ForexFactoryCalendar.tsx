import React, { useState } from 'react';
import { Clock, Globe, Filter, Calendar, TrendingUp, RefreshCw, Info, AlertTriangle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useForexFactoryCalendar } from '@/hooks/useForexFactoryCalendar';
import { ForexFactoryAPI } from '@/lib/forexFactory';

const ForexFactoryCalendar = () => {
  const [selectedTimezone, setSelectedTimezone] = useState('America/Sao_Paulo');
  const [impactFilter, setImpactFilter] = useState('All');
  const { 
    events, 
    loading, 
    lastUpdate,
    convertToTimezone, 
    getTimeUntilEvent,
    getHighImpactEvents,
    getEventsByTimeframe,
    getTodayEvents,
    getThisWeekEvents,
    refetch
  } = useForexFactoryCalendar(selectedTimezone);

  const timezones = [
    { value: 'America/Sao_Paulo', label: 'Brasil (GMT-3)' },
    { value: 'America/New_York', label: 'Nova York (GMT-5)' },
    { value: 'Europe/London', label: 'Londres (GMT+0)' },
    { value: 'Asia/Tokyo', label: 'Tóquio (GMT+9)' },
    { value: 'Australia/Sydney', label: 'Sydney (GMT+11)' }
  ];

  const filteredEvents = events.filter(event => 
    impactFilter === 'All' || event.impact === impactFilter
  );

  const highImpactEvents = getHighImpactEvents();
  const upcomingEvents = getEventsByTimeframe(24);
  const todayEvents = getTodayEvents();
  const weekEvents = getThisWeekEvents();

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'High': return 'destructive';
      case 'Medium': return 'default';
      case 'Low': return 'secondary';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      {/* Aviso informativo */}
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          <strong>Calendário ForexFactory:</strong> Dados atualizados automaticamente a cada 5 minutos. 
          Calendário exibe eventos dos próximos 7 dias. Os conectores MT4/MT5 sincronizam apenas dados de trading.
        </AlertDescription>
      </Alert>

      {/* Header com estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Eventos Hoje</p>
                <p className="text-2xl font-bold">{todayEvents.length}</p>
              </div>
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Esta Semana</p>
                <p className="text-2xl font-bold">{weekEvents.length}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Alto Impacto</p>
                <p className="text-2xl font-bold text-destructive">{highImpactEvents.length}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-destructive" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Próximas 24h</p>
                <p className="text-2xl font-bold text-primary">{upcomingEvents.length}</p>
              </div>
              <Clock className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Calendário principal */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Calendário ForexFactory
              {lastUpdate && (
                <Badge variant="outline" className="text-xs">
                  Atualizado: {lastUpdate.toLocaleTimeString('pt-BR')}
                </Badge>
              )}
            </CardTitle>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={refetch}
                disabled={loading}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Atualizar
              </Button>
              
              <Select value={selectedTimezone} onValueChange={setSelectedTimezone}>
                <SelectTrigger className="w-48">
                  <Globe className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {timezones.map(tz => (
                    <SelectItem key={tz.value} value={tz.value}>
                      {tz.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={impactFilter} onValueChange={setImpactFilter}>
                <SelectTrigger className="w-32">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="All">Todos</SelectItem>
                  <SelectItem value="High">Alto</SelectItem>
                  <SelectItem value="Medium">Médio</SelectItem>
                  <SelectItem value="Low">Baixo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p>Carregando eventos do ForexFactory...</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredEvents.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Nenhum evento encontrado para os filtros selecionados.</p>
                  <Button variant="outline" onClick={refetch} className="mt-4">
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Tentar novamente
                  </Button>
                </div>
              ) : (
                filteredEvents.map(event => (
                  <div key={event.id} className={`flex flex-col lg:flex-row lg:items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors gap-4 ${
                    event.impact === 'High' ? 'border-destructive/50 bg-destructive/5' : ''
                  }`}>
                    <div className="flex items-center gap-4 flex-1">
                      <div className="text-center min-w-[80px]">
                        <div className="text-sm font-mono font-medium">
                          {convertToTimezone(event.date, event.time, selectedTimezone)}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {getTimeUntilEvent(event.date, event.time)}
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-lg">{ForexFactoryAPI.getCountryFlag(event.country)}</span>
                          <Badge variant="outline" className="text-xs">
                            {event.currency}
                          </Badge>
                          <Badge variant={getImpactColor(event.impact)} className="text-xs">
                            {event.impact}
                          </Badge>
                        </div>
                        
                        <div className="flex-1">
                          <div className="font-medium">{event.title}</div>
                          <div className="text-sm text-muted-foreground">
                            Fonte: ForexFactory (simulado)
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex gap-6 text-sm text-muted-foreground justify-between lg:justify-end min-w-0 lg:min-w-[300px]">
                      <div className="text-center flex-1 lg:flex-none">
                        <div className="font-medium text-foreground text-xs">Anterior</div>
                        <div className="text-sm">{event.previous || 'N/A'}</div>
                      </div>
                      <div className="text-center flex-1 lg:flex-none">
                        <div className="font-medium text-foreground text-xs">Previsão</div>
                        <div className="text-sm">{event.forecast || 'N/A'}</div>
                      </div>
                      {event.actual && (
                        <div className="text-center flex-1 lg:flex-none">
                          <div className="font-medium text-foreground text-xs">Atual</div>
                          <div className="font-bold text-primary text-sm">{event.actual}</div>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ForexFactoryCalendar;