import React from 'react';
import { Clock, TrendingUp, AlertTriangle, Info } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface NewsItem {
  id: number;
  time: string;
  currency: string;
  event: string;
  impact: 'high' | 'medium' | 'low';
  forecast?: string;
  previous?: string;
}

const mockNews: NewsItem[] = [
  {
    id: 1,
    time: '14:30',
    currency: 'USD',
    event: 'Fed Interest Rate Decision',
    impact: 'high',
    forecast: '5.25%',
    previous: '5.00%'
  },
  {
    id: 2,
    time: '15:00',
    currency: 'USD',
    event: 'FOMC Statement',
    impact: 'high',
  },
  {
    id: 3,
    time: '16:30',
    currency: 'USD',
    event: 'Crude Oil Inventories',
    impact: 'medium',
    forecast: '-2.1M',
    previous: '+1.4M'
  },
  {
    id: 4,
    time: '09:30',
    currency: 'EUR',
    event: 'German IFO Business Climate',
    impact: 'medium',
    forecast: '87.2',
    previous: '86.9'
  },
  {
    id: 5,
    time: '12:00',
    currency: 'GBP',
    event: 'BOE Interest Rate Decision',
    impact: 'high',
    forecast: '5.50%',
    previous: '5.25%'
  }
];

const Newsfeed: React.FC = () => {
  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high':
        return 'text-trading-negative bg-trading-negative/10 border-trading-negative/30';
      case 'medium':
        return 'text-warning bg-warning/10 border-warning/30';
      case 'low':
        return 'text-trading-neutral bg-trading-neutral/10 border-trading-neutral/30';
      default:
        return 'text-muted-foreground bg-muted/10 border-border';
    }
  };

  const getImpactIcon = (impact: string) => {
    switch (impact) {
      case 'high':
        return <AlertTriangle className="h-3 w-3" />;
      case 'medium':
        return <TrendingUp className="h-3 w-3" />;
      case 'low':
        return <Info className="h-3 w-3" />;
      default:
        return <Info className="h-3 w-3" />;
    }
  };

  const getCurrentTime = () => {
    return new Date().toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTimeRemaining = (eventTime: string) => {
    const now = new Date();
    const [hours, minutes] = eventTime.split(':');
    const eventDate = new Date();
    eventDate.setHours(parseInt(hours), parseInt(minutes), 0, 0);
    
    if (eventDate < now) {
      eventDate.setDate(eventDate.getDate() + 1);
    }
    
    const diff = eventDate.getTime() - now.getTime();
    const hoursRemaining = Math.floor(diff / (1000 * 60 * 60));
    const minutesRemaining = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hoursRemaining > 0) {
      return `${hoursRemaining}h ${minutesRemaining}m`;
    }
    return `${minutesRemaining}m`;
  };

  return (
    <Card className="bg-gradient-card border-border shadow-card">
      <CardHeader>
        <CardTitle className="text-card-foreground flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Calendário Econômico - Hoje
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {mockNews.map((item) => (
            <div key={item.id} className="flex items-center justify-between p-4 rounded-lg bg-muted/20 hover:bg-muted/30 transition-colors">
              <div className="flex items-center gap-4">
                <div className="flex flex-col items-center text-center min-w-[60px]">
                  <span className="font-mono text-sm font-medium text-card-foreground">{item.time}</span>
                  <span className="text-xs text-muted-foreground">
                    {getTimeRemaining(item.time)}
                  </span>
                </div>
                
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30 font-mono">
                    {item.currency}
                  </Badge>
                  
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-card-foreground">{item.event}</span>
                      <Badge 
                        variant="outline" 
                        className={cn("text-xs px-2 py-0.5", getImpactColor(item.impact))}
                      >
                        {getImpactIcon(item.impact)}
                        <span className="ml-1 capitalize">{item.impact}</span>
                      </Badge>
                    </div>
                    
                    {(item.forecast || item.previous) && (
                      <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground font-mono">
                        {item.forecast && (
                          <span>Prev: {item.forecast}</span>
                        )}
                        {item.previous && (
                          <span>Ant: {item.previous}</span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-xs text-muted-foreground">
                  Notificar
                </div>
                <div className="w-4 h-4 rounded border border-border bg-muted/50 hover:bg-muted cursor-pointer mt-1"></div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 pt-4 border-t border-border text-center">
          <p className="text-xs text-muted-foreground">
            Próxima atualização: {getCurrentTime()} • 
            <span className="text-primary ml-1 cursor-pointer hover:underline">
              Ver calendário completo
            </span>
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export { Newsfeed };