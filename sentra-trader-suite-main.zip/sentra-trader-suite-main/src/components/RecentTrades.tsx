import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface Trade {
  id: number;
  symbol: string;
  type: 'buy' | 'sell';
  volume: number;
  openPrice: number;
  closePrice: number;
  profit: number;
  openTime: string;
  closeTime: string;
}

const mockTrades: Trade[] = [
  {
    id: 1,
    symbol: 'EURUSD',
    type: 'buy',
    volume: 0.10,
    openPrice: 1.0850,
    closePrice: 1.0875,
    profit: 25.00,
    openTime: '2025-09-12 10:30:00',
    closeTime: '2025-09-12 11:15:00'
  },
  {
    id: 2,
    symbol: 'GBPUSD',
    type: 'sell',
    volume: 0.15,
    openPrice: 1.2650,
    closePrice: 1.2630,
    profit: 30.00,
    openTime: '2025-09-12 09:15:00',
    closeTime: '2025-09-12 10:05:00'
  },
  {
    id: 3,
    symbol: 'USDJPY',
    type: 'buy',
    volume: 0.08,
    openPrice: 149.50,
    closePrice: 149.25,
    profit: -20.00,
    openTime: '2025-09-12 08:45:00',
    closeTime: '2025-09-12 09:30:00'
  },
  {
    id: 4,
    symbol: 'AUDUSD',
    type: 'sell',
    volume: 0.12,
    openPrice: 0.6750,
    closePrice: 0.6735,
    profit: 18.00,
    openTime: '2025-09-12 07:20:00',
    closeTime: '2025-09-12 08:10:00'
  },
  {
    id: 5,
    symbol: 'USDCAD',
    type: 'buy',
    volume: 0.20,
    openPrice: 1.3580,
    closePrice: 1.3595,
    profit: 22.00,
    openTime: '2025-09-12 06:30:00',
    closeTime: '2025-09-12 07:15:00'
  }
];

const RecentTrades: React.FC = () => {
  const formatTime = (timeString: string) => {
    return new Date(timeString).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Card className="bg-gradient-card border-border shadow-card">
      <CardHeader>
        <CardTitle className="text-card-foreground">Trades Recentes</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {mockTrades.map((trade) => (
            <div key={trade.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "p-2 rounded-lg",
                  trade.type === 'buy' ? "bg-trading-positive/10" : "bg-primary/10"
                )}>
                  {trade.type === 'buy' ? (
                    <ArrowUpRight className="h-4 w-4 text-trading-positive" />
                  ) : (
                    <ArrowDownRight className="h-4 w-4 text-primary" />
                  )}
                </div>
                
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-card-foreground">{trade.symbol}</span>
                    <Badge 
                      variant="outline" 
                      className={cn(
                        "text-xs px-2 py-0.5",
                        trade.type === 'buy' 
                          ? "border-trading-positive/30 text-trading-positive bg-trading-positive/10" 
                          : "border-primary/30 text-primary bg-primary/10"
                      )}
                    >
                      {trade.type.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {trade.volume} lots • {formatTime(trade.closeTime)}
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <div className={cn(
                  "font-mono font-medium",
                  trade.profit > 0 ? "text-trading-positive" : "text-trading-negative"
                )}>
                  {trade.profit > 0 ? '+' : ''}${trade.profit.toFixed(2)}
                </div>
                <div className="text-xs text-muted-foreground font-mono">
                  {trade.openPrice} → {trade.closePrice}
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Total P&L Hoje:</span>
            <span className="font-mono font-medium text-trading-positive">
              +$75.00
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export { RecentTrades };