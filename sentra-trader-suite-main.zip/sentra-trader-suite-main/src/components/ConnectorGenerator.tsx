import React, { useState } from 'react';
import { Download, Code, Shield, AlertTriangle, CheckCircle, Copy } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';

interface ConnectorGeneratorProps {
  accountId: string;
  accountNumber: string;
  userEmail: string;
}

const ConnectorGenerator: React.FC<ConnectorGeneratorProps> = ({ 
  accountId, 
  accountNumber, 
  userEmail 
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  const generateMT5Connector = () => {
    const mt5Code = `//+------------------------------------------------------------------+
//|                                    SentraConnector_Simple.mq5   |
//|                        Copyright 2025, Sentra Partners & Manus AI |
//+------------------------------------------------------------------+
#property copyright "Copyright 2025, Sentra Partners & Manus AI"
#property version   "1.00"
#property strict
#property description "Conector simples - apenas sincronização de dados"

//--- Configurações da conta
input string InpUserID = "${accountId}"; // ID do Usuário (Supabase)
input string InpInvestorPassword = ""; // Senha de Investidor
input int InpUpdateInterval = 60; // Intervalo de atualização (segundos)

//--- Globals
string G_ApiKey = "";
string G_AccountID = "${accountId}";
string G_ApiUrl = "https://haoflzjojbvyhqpilpza.supabase.co";
string G_SupabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhhb2ZsempvamJ2eWhxcGlscHphIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc2OTIzMjQsImV4cCI6MjA3MzI2ODMyNH0.AkAc7vwDagpG8xT6zY5_Q4SRrVlNYyR9teaDSyxP1zM";
ulong G_LastUpdateTime = 0;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
    Print("SentraConnector Simple: Iniciando sincronização para conta ${accountNumber}...");
    EventSetTimer(InpUpdateInterval);
    
    if(InpInvestorPassword == "")
    {
        Print("SentraConnector: ERRO - Senha de investidor não configurada!");
        Print("SentraConnector: Configure a senha no campo InpInvestorPassword");
        return(INIT_FAILED);
    }

    OnTimer();
    return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
    EventKillTimer();
    Print("SentraConnector Simple: Finalizado para conta ${accountNumber}.");
}

//+------------------------------------------------------------------+
//| Expert timer function                                            |
//+------------------------------------------------------------------+
void OnTimer()
{
    if(G_ApiKey == "")
    {
        if(!Authenticate())
        {
            Print("SentraConnector: Falha na autenticação. Tentando novamente em ", InpUpdateInterval, " segundos.");
            return;
        }
    }

    // Apenas sincronizar dados - SEM interferir no trading
    SendAccountData();
    SendOpenPositions();
    
    G_LastUpdateTime = GetTickCount();
    Print("SentraConnector: Dados sincronizados com sucesso para ${userEmail}");
}

//+------------------------------------------------------------------+
//| Autenticação com a API                                           |
//+------------------------------------------------------------------+
bool Authenticate()
{
    string accountNumber = IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN));
    
    string jsonString = "{\\"p_account_number\\":\\"" + accountNumber + "\\", \\"p_investor_password\\":\\"" + InpInvestorPassword + "\\", \\"p_user_id\\":\\"" + InpUserID + "\\" }";
    char post[], result[];
    int res;

    string headers = "apikey: " + G_SupabaseKey + "\\r\\n" +
                     "Authorization: Bearer " + G_SupabaseKey + "\\r\\n" +
                     "Content-Type: application/json";

    StringToCharArray(jsonString, post);
    res = WebRequest("POST", G_ApiUrl + "/rest/v1/rpc/authenticate_connector", headers, 5000, post, result);

    if(res == -1)
    {
        Print("SentraConnector: Erro no WebRequest: ", GetLastError());
        return false;
    }
    
    string resultStr = CharArrayToString(result);
    
    if(StringFind(resultStr, "api_key") > -1)
    {
        // Extração simples da API key
        int start = StringFind(resultStr, "\\"api_key\\":\\"") + 12;
        int end = StringFind(resultStr, "\\"", start);
        G_ApiKey = StringSubstr(resultStr, start, end - start);
        Print("SentraConnector: Autenticado com sucesso!");
        return true;
    }
    else
    {
        Print("SentraConnector: Falha na autenticação - ", resultStr);
        return false;
    }
}

//+------------------------------------------------------------------+
//| Envia dados da conta                                             |
//+------------------------------------------------------------------+
void SendAccountData()
{
    string json = "[{";
    json = json + "\\"account_id\\":\\"" + G_AccountID + "\\",";
    json = json + "\\"api_key\\":\\"" + G_ApiKey + "\\",";
    json = json + "\\"balance\\":" + DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE), 2) + ",";
    json = json + "\\"equity\\":" + DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2) + ",";
    json = json + "\\"profit\\":" + DoubleToString(AccountInfoDouble(ACCOUNT_PROFIT), 2) + ",";
    json = json + "\\"margin\\":" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN), 2) + ",";
    json = json + "\\"margin_free\\":" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2) + ",";
    json = json + "\\"margin_level\\":" + DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_LEVEL), 2) + ",";
    json = json + "\\"open_trades_count\\":" + IntegerToString(PositionsTotal()) + ",";
    json = json + "\\"last_update_source\\":\\"mt5_connector_simple_v1.0\\"";
    json = json + "}]";

    char post[], result[];
    string headers = "apikey: " + G_SupabaseKey + "\\r\\n" +
                     "Authorization: Bearer " + G_SupabaseKey + "\\r\\n" +
                     "Content-Type: application/json\\r\\n" +
                     "Prefer: resolution=merge-duplicates";

    StringToCharArray(json, post);
    WebRequest("POST", G_ApiUrl + "/rest/v1/trading_updates", headers, 5000, post, result);
}

//+------------------------------------------------------------------+
//| Envia posições abertas                                           |
//+------------------------------------------------------------------+
void SendOpenPositions()
{
    string json = "[";
    bool first = true;
    
    for(int i = 0; i < PositionsTotal(); i++)
    {
        ulong ticket = PositionGetTicket(i);
        if(ticket > 0)
        {
            if(!first) json = json + ",";
            first = false;
            
            json = json + "{";
            json = json + "\\"account_id\\":\\"" + G_AccountID + "\\",";
            json = json + "\\"ticket\\":" + IntegerToString((long)ticket) + ",";
            json = json + "\\"symbol\\":\\"" + PositionGetString(POSITION_SYMBOL) + "\\",";
            json = json + "\\"type\\":\\"" + (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY ? "BUY" : "SELL") + "\\",";
            json = json + "\\"volume\\":" + DoubleToString(PositionGetDouble(POSITION_VOLUME), 2) + ",";
            json = json + "\\"open_time\\":\\"" + TimeToString((datetime)PositionGetInteger(POSITION_TIME), TIME_DATE|TIME_SECONDS) + "\\",";
            json = json + "\\"open_price\\":" + DoubleToString(PositionGetDouble(POSITION_PRICE_OPEN), 5) + ",";
            json = json + "\\"current_price\\":" + DoubleToString(PositionGetDouble(POSITION_PRICE_CURRENT), 5) + ",";
            json = json + "\\"profit\\":" + DoubleToString(PositionGetDouble(POSITION_PROFIT), 2) + ",";
            json = json + "\\"commission\\":" + DoubleToString(PositionGetDouble(POSITION_COMMISSION), 2) + ",";
            json = json + "\\"swap\\":" + DoubleToString(PositionGetDouble(POSITION_SWAP), 2);
            json = json + "}";
        }
    }
    json = json + "]";

    if(PositionsTotal() > 0)
    {
        char post[], result[];
        string headers = "apikey: " + G_SupabaseKey + "\\r\\n" +
                         "Authorization: Bearer " + G_SupabaseKey + "\\r\\n" +
                         "Content-Type: application/json";

        StringToCharArray(json, post);
        WebRequest("POST", G_ApiUrl + "/rest/v1/open_positions", headers, 5000, post, result);
    }
}
//+------------------------------------------------------------------+`;

    return mt5Code;
  };

  const generateMT4Connector = () => {
    const mt4Code = `//+------------------------------------------------------------------+
//|                                    SentraConnector_Simple.mq4   |
//|                        Copyright 2025, Sentra Partners & Manus AI |
//+------------------------------------------------------------------+
#property copyright "Copyright 2025, Sentra Partners & Manus AI"
#property version   "1.00"
#property strict
#property description "Conector simples MT4 - apenas sincronização de dados"

//--- Configurações da conta
extern string InpUserID = "${accountId}"; // ID do Usuário (Supabase)
extern string InpInvestorPassword = ""; // Senha de Investidor
extern int InpUpdateInterval = 60; // Intervalo de atualização (segundos)

//--- Globals
string G_ApiKey = "";
string G_AccountID = "${accountId}";
string G_ApiUrl = "https://haoflzjojbvyhqpilpza.supabase.co";
string G_SupabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhhb2ZsempvamJ2eWhxcGlscHphIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc2OTIzMjQsImV4cCI6MjA3MzI2ODMyNH0.AkAc7vwDagpG8xT6zY5_Q4SRrVlNYyR9teaDSyxP1zM";
datetime G_LastHistoryCheck = 0;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
{
    Print("SentraConnector Simple MT4: Iniciando sincronização para conta ${accountNumber}...");
    
    if(InpInvestorPassword == "")
    {
        Print("SentraConnector MT4: ERRO - Senha de investidor não configurada!");
        Print("SentraConnector MT4: Configure a senha no campo InpInvestorPassword");
        return(INIT_FAILED);
    }

    start();
    return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void deinit()
{
    Print("SentraConnector Simple MT4: Finalizado para conta ${accountNumber}.");
}

//+------------------------------------------------------------------+
//| Expert start function                                            |
//+------------------------------------------------------------------+
int start()
{
    if(TimeCurrent() - G_LastHistoryCheck < InpUpdateInterval)
    {
        return(0);
    }

    if(G_ApiKey == "")
    {
        if(!Authenticate())
        {
            Print("SentraConnector MT4: Falha na autenticação.");
            return(0);
        }
    }

    // Apenas sincronizar dados - SEM interferir no trading
    SendAccountData();
    SendOpenPositions();
    
    G_LastHistoryCheck = TimeCurrent();
    Print("SentraConnector MT4: Dados sincronizados com sucesso para ${userEmail}");
    return(0);
}

//+------------------------------------------------------------------+
//| Autenticação com a API                                           |
//+------------------------------------------------------------------+
bool Authenticate()
{
    string accountNumber = IntegerToString(AccountNumber());
    
    string jsonString = "{\\"p_account_number\\":\\"" + accountNumber + "\\", \\"p_investor_password\\":\\"" + InpInvestorPassword + "\\", \\"p_user_id\\":\\"" + InpUserID + "\\" }";
    char post[], result[];
    int res;

    string headers = "apikey: " + G_SupabaseKey + "\\r\\n" +
                     "Authorization: Bearer " + G_SupabaseKey + "\\r\\n" +
                     "Content-Type: application/json";

    StringToCharArray(jsonString, post, 0, StringLen(jsonString), CP_UTF8);
    res = WebRequest("POST", G_ApiUrl + "/rest/v1/rpc/authenticate_connector", headers, 5000, post, result);

    if(res == -1)
    {
        Print("SentraConnector MT4: Erro no WebRequest: ", GetLastError());
        return false;
    }
    
    string resultStr = CharArrayToString(result);
    
    if(StringFind(resultStr, "api_key") > -1)
    {
        // Extração simples da API key
        int start = StringFind(resultStr, "\\"api_key\\":\\"") + 12;
        int end = StringFind(resultStr, "\\"", start);
        G_ApiKey = StringSubstr(resultStr, start, end - start);
        Print("SentraConnector MT4: Autenticado com sucesso!");
        return true;
    }
    else
    {
        Print("SentraConnector MT4: Falha na autenticação - ", resultStr);
        return false;
    }
}

//+------------------------------------------------------------------+
//| Envia dados da conta                                             |
//+------------------------------------------------------------------+
void SendAccountData()
{
    string json = "[{";
    json = json + "\\"account_id\\":\\"" + G_AccountID + "\\",";
    json = json + "\\"api_key\\":\\"" + G_ApiKey + "\\",";
    json = json + "\\"balance\\":" + DoubleToStr(AccountBalance(), 2) + ",";
    json = json + "\\"equity\\":" + DoubleToStr(AccountEquity(), 2) + ",";
    json = json + "\\"profit\\":" + DoubleToStr(AccountProfit(), 2) + ",";
    json = json + "\\"margin\\":" + DoubleToStr(AccountMargin(), 2) + ",";
    json = json + "\\"margin_free\\":" + DoubleToStr(AccountFreeMargin(), 2) + ",";
    json = json + "\\"margin_level\\":" + DoubleToStr(AccountMarginLevel(), 2) + ",";
    json = json + "\\"open_trades_count\\":" + IntegerToString(OrdersTotal()) + ",";
    json = json + "\\"last_update_source\\":\\"mt4_connector_simple_v1.0\\"";
    json = json + "}]";

    char post[], result[];
    string headers = "apikey: " + G_SupabaseKey + "\\r\\n" +
                     "Authorization: Bearer " + G_SupabaseKey + "\\r\\n" +
                     "Content-Type: application/json\\r\\n" +
                     "Prefer: resolution=merge-duplicates";

    StringToCharArray(json, post, 0, StringLen(json), CP_UTF8);
    WebRequest("POST", G_ApiUrl + "/rest/v1/trading_updates", headers, 5000, post, result);
}

//+------------------------------------------------------------------+
//| Envia posições abertas (orders para MT4)                        |
//+------------------------------------------------------------------+
void SendOpenPositions()
{
    string json = "[";
    bool first = true;
    
    for(int i = 0; i < OrdersTotal(); i++)
    {
        if(OrderSelect(i, SELECT_BY_POS) && (OrderType() == OP_BUY || OrderType() == OP_SELL))
        {
            if(!first) json = json + ",";
            first = false;
            
            json = json + "{";
            json = json + "\\"account_id\\":\\"" + G_AccountID + "\\",";
            json = json + "\\"ticket\\":" + IntegerToString(OrderTicket()) + ",";
            json = json + "\\"symbol\\":\\"" + OrderSymbol() + "\\",";
            json = json + "\\"type\\":\\"" + (OrderType() == OP_BUY ? "BUY" : "SELL") + "\\",";
            json = json + "\\"volume\\":" + DoubleToStr(OrderLots(), 2) + ",";
            json = json + "\\"open_time\\":\\"" + TimeToStr(OrderOpenTime(), TIME_DATE|TIME_SECONDS) + "\\",";
            json = json + "\\"open_price\\":" + DoubleToStr(OrderOpenPrice(), 5) + ",";
            json = json + "\\"current_price\\":" + DoubleToStr(MarketInfo(OrderSymbol(), MODE_BID), 5) + ",";
            json = json + "\\"profit\\":" + DoubleToStr(OrderProfit(), 2) + ",";
            json = json + "\\"commission\\":" + DoubleToStr(OrderCommission(), 2) + ",";
            json = json + "\\"swap\\":" + DoubleToStr(OrderSwap(), 2);
            json = json + "}";
        }
    }
    json = json + "]";

    if(OrdersTotal() > 0)
    {
        char post[], result[];
        string headers = "apikey: " + G_SupabaseKey + "\\r\\n" +
                         "Authorization: Bearer " + G_SupabaseKey + "\\r\\n" +
                         "Content-Type: application/json";

        StringToCharArray(json, post, 0, StringLen(json), CP_UTF8);
        WebRequest("POST", G_ApiUrl + "/rest/v1/open_positions", headers, 5000, post, result);
    }
}
//+------------------------------------------------------------------+`;

    return mt4Code;
  };

  const downloadFile = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownload = (type: 'MT4' | 'MT5') => {
    setIsGenerating(true);
    
    try {
      const content = type === 'MT5' ? generateMT5Connector() : generateMT4Connector();
      const filename = `SentraConnector_${accountNumber}_${type}.${type === 'MT5' ? 'mq5' : 'mq4'}`;
      
      downloadFile(content, filename);
      
      toast({
        title: "Conector gerado!",
        description: `Arquivo ${filename} baixado com sucesso.`
      });
      
    } catch (error) {
      console.error('Erro ao gerar conector:', error);
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao gerar o conector.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = async (content: string) => {
    try {
      await navigator.clipboard.writeText(content);
      toast({
        title: "Código copiado!",
        description: "O código foi copiado para a área de transferência."
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível copiar o código.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      <Alert>
        <Shield className="h-4 w-4" />
        <AlertDescription>
          <strong>Conectores Simples:</strong> Estes conectores APENAS sincronizam dados de trading.
          Não interferem em suas operações ou estratégias automáticas.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code className="h-5 w-5" />
            Gerador de Conectores MT4/MT5
            <Badge variant="outline">Versão Simples</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">MetaTrader 5</h3>
                <Badge variant="secondary">MT5</Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Conector para plataforma MT5 com sincronização em tempo real
              </p>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Dados de conta em tempo real</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Posições abertas</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <AlertTriangle className="h-4 w-4 text-yellow-500" />
                  <span>SEM interferência no trading</span>
                </div>
              </div>
              <Button 
                onClick={() => handleDownload('MT5')} 
                className="w-full mt-4"
                disabled={isGenerating}
              >
                <Download className="h-4 w-4 mr-2" />
                {isGenerating ? 'Gerando...' : 'Baixar MT5 (.mq5)'}
              </Button>
            </div>

            <div className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">MetaTrader 4</h3>
                <Badge variant="secondary">MT4</Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Conector para plataforma MT4 com funcionalidades essenciais
              </p>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Dados de conta em tempo real</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Orders abertas</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <AlertTriangle className="h-4 w-4 text-yellow-500" />
                  <span>SEM interferência no trading</span>
                </div>
              </div>
              <Button 
                onClick={() => handleDownload('MT4')} 
                className="w-full mt-4"
                disabled={isGenerating}
              >
                <Download className="h-4 w-4 mr-2" />
                {isGenerating ? 'Gerando...' : 'Baixar MT4 (.mq4)'}
              </Button>
            </div>
          </div>

          <Tabs defaultValue="instructions" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="instructions">Instruções</TabsTrigger>
              <TabsTrigger value="mt5-code">Código MT5</TabsTrigger>
              <TabsTrigger value="mt4-code">Código MT4</TabsTrigger>
            </TabsList>
            
            <TabsContent value="instructions" className="space-y-4">
              <div className="p-4 border rounded-lg">
                <h3 className="font-semibold mb-2">Como usar:</h3>
                <ol className="list-decimal list-inside space-y-2 text-sm">
                  <li>Baixe o conector apropriado (MT4 ou MT5)</li>
                  <li>Copie o arquivo para a pasta MQL4/Experts (MT4) ou MQL5/Experts (MT5)</li>
                  <li>Compile o código no MetaEditor</li>
                  <li>Configure a senha de investidor no campo InpInvestorPassword</li>
                  <li>Anexe o Expert Advisor ao gráfico</li>
                  <li>Aguarde a sincronização automática dos dados</li>
                </ol>
              </div>
              
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Importante:</strong> Configure sua senha de investidor antes de usar o conector.
                  O conector NÃO executa trades, apenas monitora sua conta.
                </AlertDescription>
              </Alert>
            </TabsContent>
            
            <TabsContent value="mt5-code">
              <div className="relative">
                <Button
                  variant="outline"
                  size="sm"
                  className="absolute top-2 right-2 z-10"
                  onClick={() => copyToClipboard(generateMT5Connector())}
                >
                  <Copy className="h-4 w-4" />
                </Button>
                <pre className="bg-muted p-4 rounded-lg overflow-auto max-h-96 text-xs">
                  <code>{generateMT5Connector()}</code>
                </pre>
              </div>
            </TabsContent>
            
            <TabsContent value="mt4-code">
              <div className="relative">
                <Button
                  variant="outline"
                  size="sm"
                  className="absolute top-2 right-2 z-10"
                  onClick={() => copyToClipboard(generateMT4Connector())}
                >
                  <Copy className="h-4 w-4" />
                </Button>
                <pre className="bg-muted p-4 rounded-lg overflow-auto max-h-96 text-xs">
                  <code>{generateMT4Connector()}</code>
                </pre>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default ConnectorGenerator;