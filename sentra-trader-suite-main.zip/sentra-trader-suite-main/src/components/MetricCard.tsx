import React from 'react';
import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface MetricCardProps {
  title: string;
  value: string;
  change?: string;
  icon: LucideIcon;
  trend: 'positive' | 'negative' | 'neutral';
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, change, icon: Icon, trend }) => {
  return (
    <Card className="bg-gradient-card border-border shadow-card hover:shadow-trading transition-shadow duration-300">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <p className="text-sm text-muted-foreground font-medium">{title}</p>
            <p className="text-2xl font-bold font-mono text-card-foreground mt-2">{value}</p>
            
            {change && (
              <div className="flex items-center gap-1 mt-2">
                {trend === 'positive' ? (
                  <TrendingUp className="h-3 w-3 text-trading-positive" />
                ) : trend === 'negative' ? (
                  <TrendingDown className="h-3 w-3 text-trading-negative" />
                ) : null}
                <span 
                  className={cn(
                    "text-xs font-medium",
                    trend === 'positive' && "text-trading-positive",
                    trend === 'negative' && "text-trading-negative",
                    trend === 'neutral' && "text-trading-neutral"
                  )}
                >
                  {change}
                </span>
              </div>
            )}
          </div>
          
          <div className={cn(
            "p-3 rounded-xl",
            trend === 'positive' && "bg-trading-positive/10",
            trend === 'negative' && "bg-trading-negative/10",
            trend === 'neutral' && "bg-primary/10"
          )}>
            <Icon className={cn(
              "h-6 w-6",
              trend === 'positive' && "text-trading-positive",
              trend === 'negative' && "text-trading-negative", 
              trend === 'neutral' && "text-primary"
            )} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export { MetricCard };