import { useState, useEffect } from 'react';
import { ForexFactoryAPI } from '@/lib/forexFactory';

interface ForexFactoryEvent {
  id: string;
  title: string;
  country: string;
  currency: string;
  date: string;
  time: string;
  impact: 'Low' | 'Medium' | 'High';
  forecast: string;
  previous: string;
  actual?: string;
}

export const useForexFactoryCalendar = (timezone: string = 'America/Sao_Paulo') => {
  const [events, setEvents] = useState<ForexFactoryEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  useEffect(() => {
    fetchEvents();
    
    // Atualizar a cada 5 minutos para tempo real
    const interval = setInterval(fetchEvents, 5 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, []);

  const fetchEvents = async () => {
    try {
      setLoading(true);
      const allEvents: ForexFactoryEvent[] = [];
      
      // Buscar eventos dos próximos 7 dias
      for (let i = 0; i < 7; i++) {
        const date = new Date();
        date.setDate(date.getDate() + i);
        const dateStr = date.toISOString().split('T')[0];
        
        try {
          const dayEvents = await ForexFactoryAPI.fetchCalendarData(dateStr);
          allEvents.push(...dayEvents);
        } catch (error) {
          console.error(`Erro ao buscar eventos para ${dateStr}:`, error);
        }
      }
      
      // Ordenar por data e hora
      allEvents.sort((a, b) => {
        const dateTimeA = new Date(`${a.date}T${a.time}:00`);
        const dateTimeB = new Date(`${b.date}T${b.time}:00`);
        return dateTimeA.getTime() - dateTimeB.getTime();
      });
      
      setEvents(allEvents);
      setLastUpdate(new Date());
    } catch (error) {
      console.error('Erro ao buscar eventos do ForexFactory:', error);
    } finally {
      setLoading(false);
    }
  };

  const convertToTimezone = (date: string, time: string, tz: string): string => {
    try {
      const datetime = new Date(`${date}T${time}:00`);
      return datetime.toLocaleString('pt-BR', { 
        timeZone: tz,
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch (error) {
      return time;
    }
  };

  const getTimeUntilEvent = (date: string, time: string): string => {
    try {
      const eventDateTime = new Date(`${date}T${time}:00`);
      const now = new Date();
      const diff = eventDateTime.getTime() - now.getTime();
      
      if (diff < 0) return 'Já ocorreu';
      
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      
      if (hours > 24) {
        const days = Math.floor(hours / 24);
        return `Em ${days} dia${days > 1 ? 's' : ''}`;
      }
      
      if (hours > 0) {
        return `Em ${hours}h ${minutes}min`;
      }
      
      return `Em ${minutes} min`;
    } catch (error) {
      return 'Tempo indeterminado';
    }
  };

  const getHighImpactEvents = (): ForexFactoryEvent[] => {
    return events.filter(event => event.impact === 'High');
  };

  const getEventsByTimeframe = (hours: number): ForexFactoryEvent[] => {
    const now = new Date();
    const timeframe = new Date(now.getTime() + hours * 60 * 60 * 1000);
    
    return events.filter(event => {
      const eventTime = new Date(`${event.date}T${event.time}:00`);
      return eventTime >= now && eventTime <= timeframe;
    });
  };

  const getTodayEvents = (): ForexFactoryEvent[] => {
    const today = new Date().toISOString().split('T')[0];
    return events.filter(event => event.date === today);
  };

  const getThisWeekEvents = (): ForexFactoryEvent[] => {
    const today = new Date();
    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay()); // Start of week
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6); // End of week
    
    const weekStartStr = weekStart.toISOString().split('T')[0];
    const weekEndStr = weekEnd.toISOString().split('T')[0];
    
    return events.filter(event => 
      event.date >= weekStartStr && event.date <= weekEndStr
    );
  };

  return { 
    events, 
    loading, 
    lastUpdate,
    convertToTimezone, 
    getTimeUntilEvent,
    getHighImpactEvents,
    getEventsByTimeframe,
    getTodayEvents,
    getThisWeekEvents,
    refetch: fetchEvents
  };
};