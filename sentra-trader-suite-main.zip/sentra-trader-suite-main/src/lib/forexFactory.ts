import { supabase } from '@/integrations/supabase/client';

interface ForexFactoryEvent {
  id: string;
  title: string;
  country: string;
  currency: string;
  date: string;
  time: string;
  impact: 'Low' | 'Medium' | 'High';
  forecast: string;
  previous: string;
  actual?: string;
}

export class ForexFactoryAPI {
  private static readonly FF_BASE_URL = 'https://www.forexfactory.com';

  static async fetchCalendarData(date?: string): Promise<ForexFactoryEvent[]> {
    try {
      const targetDate = date || new Date().toISOString().split('T')[0];
      
      // Primeiro, tenta buscar do cache local
      const cachedEvents = await ForexFactoryAPI.getCachedEvents(targetDate);
      if (cachedEvents.length > 0) {
        console.log('ForexFactory: Usando eventos em cache');
        return cachedEvents;
      }

      // Se não há cache, simular alguns eventos para demonstração
      // Em produção, você implementaria o proxy para scraping real
      const simulatedEvents = ForexFactoryAPI.generateSimulatedEvents(targetDate);
      
      // Salvar no cache
      await ForexFactoryAPI.cacheEvents(simulatedEvents);
      
      return simulatedEvents;
    } catch (error) {
      console.error('Erro ao buscar dados do ForexFactory:', error);
      return await ForexFactoryAPI.getCachedEvents(date);
    }
  }

  private static generateSimulatedEvents(date: string): ForexFactoryEvent[] {
    const currencies = ['USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF'];
    const countries: { [key: string]: string } = {
      'USD': 'US', 'EUR': 'EU', 'GBP': 'GB', 'JPY': 'JP',
      'AUD': 'AU', 'CAD': 'CA', 'CHF': 'CH'
    };
    
    const events = [
      {
        title: 'Non-Farm Employment Change',
        impact: 'High' as const,
        time: '15:30',
        currency: 'USD'
      },
      {
        title: 'GDP Growth Rate',
        impact: 'High' as const,
        time: '10:00',
        currency: 'EUR'
      },
      {
        title: 'Interest Rate Decision',
        impact: 'High' as const,
        time: '14:00',
        currency: 'GBP'
      },
      {
        title: 'Consumer Price Index',
        impact: 'Medium' as const,
        time: '09:00',
        currency: 'JPY'
      },
      {
        title: 'Retail Sales',
        impact: 'Medium' as const,
        time: '11:30',
        currency: 'AUD'
      },
      {
        title: 'Employment Rate',
        impact: 'Low' as const,
        time: '16:00',
        currency: 'CAD'
      }
    ];

    return events.map((event, index) => ({
      id: `ff_${date}_${index}`,
      title: event.title,
      country: countries[event.currency],
      currency: event.currency,
      date: date,
      time: event.time,
      impact: event.impact,
      forecast: Math.random() > 0.5 ? (Math.random() * 100).toFixed(1) : '',
      previous: (Math.random() * 100).toFixed(1),
      actual: Math.random() > 0.7 ? (Math.random() * 100).toFixed(1) : undefined
    }));
  }

  private static async cacheEvents(events: ForexFactoryEvent[]): Promise<void> {
    try {
      for (const event of events) {
        await supabase
          .from('forex_factory_events')
          .upsert({
            ff_event_id: event.id,
            title: event.title,
            country: event.country,
            currency: event.currency,
            event_date: event.date,
            event_time: event.time,
            impact: event.impact,
            forecast: event.forecast,
            previous: event.previous,
            actual: event.actual,
            last_updated: new Date().toISOString()
          }, {
            onConflict: 'ff_event_id'
          });
      }
    } catch (error) {
      console.error('Erro ao cachear eventos:', error);
    }
  }

  private static async getCachedEvents(date?: string): Promise<ForexFactoryEvent[]> {
    try {
      const targetDate = date || new Date().toISOString().split('T')[0];
      
      const { data, error } = await supabase
        .from('forex_factory_events')
        .select('*')
        .eq('event_date', targetDate)
        .order('event_time', { ascending: true });

      if (error) {
        console.error('Erro ao buscar cache:', error);
        return [];
      }

      return data?.map(event => ({
        id: event.ff_event_id,
        title: event.title,
        country: event.country,
        currency: event.currency,
        date: event.event_date,
        time: event.event_time,
        impact: event.impact as 'Low' | 'Medium' | 'High',
        forecast: event.forecast || '',
        previous: event.previous || '',
        actual: event.actual || undefined
      })) || [];
    } catch (error) {
      console.error('Erro ao buscar eventos em cache:', error);
      return [];
    }
  }

  static getCountryFromCurrency(currency: string): string {
    const currencyMap: { [key: string]: string } = {
      'USD': 'US', 'EUR': 'EU', 'GBP': 'GB', 'JPY': 'JP',
      'CAD': 'CA', 'AUD': 'AU', 'CHF': 'CH', 'NZD': 'NZ',
      'CNY': 'CN', 'BRL': 'BR'
    };
    return currencyMap[currency] || 'XX';
  }

  static getCountryFlag(country: string): string {
    const flags: { [key: string]: string } = {
      'US': '🇺🇸', 'EU': '🇪🇺', 'GB': '🇬🇧', 'JP': '🇯🇵',
      'CA': '🇨🇦', 'AU': '🇦🇺', 'CH': '🇨🇭', 'BR': '🇧🇷',
      'NZ': '🇳🇿', 'CN': '🇨🇳', 'XX': '🌍'
    };
    return flags[country] || '🌍';
  }
}