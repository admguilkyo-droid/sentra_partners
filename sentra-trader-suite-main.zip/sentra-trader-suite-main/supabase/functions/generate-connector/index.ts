import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': 'https://haoflzjojbvyhqpilpza.supabase.co',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { accountId, platform } = await req.json();

    // Validate input
    if (!accountId || !platform) {
      return new Response(
        JSON.stringify({ error: 'Account ID and platform are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!['MT4', 'MT5'].includes(platform)) {
      return new Response(
        JSON.stringify({ error: 'Invalid platform. Must be MT4 or MT5' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    
    // Get auth user from header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Authorization required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Invalid token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch account data and rotate API key for security
    const { data: accountData, error: fetchError } = await supabaseClient
      .from('trading_accounts')
      .select('*')
      .eq('id', accountId)
      .eq('user_id', user.id)
      .single();

    if (fetchError || !accountData) {
      console.error('Account access error:', fetchError);
      return new Response(
        JSON.stringify({ error: 'Account not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Rotate API key for enhanced security
    const { data: newApiKey, error: rotateError } = await supabaseClient
      .rpc('rotate_api_key', { account_uuid: accountId });

    if (rotateError) {
      console.error('API key rotation error:', rotateError);
      return new Response(
        JSON.stringify({ error: 'Security setup failed' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Update account object with new API key
    accountData.api_key = newApiKey;

    // Generate EA code based on platform
    const eaCode = generateEACode(accountData, platform);
    const fileName = `SentraConnector_${platform}_${accountData.account_number}.${platform.toLowerCase()}`;

    return new Response(eaCode, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/octet-stream',
        'Content-Disposition': `attachment; filename="${fileName}"`,
      }
    });

  } catch (error) {
    console.error('Error generating connector:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function generateEACode(accountData: any, platform: string): string {
  const apiEndpoint = Deno.env.get('SUPABASE_URL') + '/functions/v1';
  
  if (platform === 'MT5') {
    return getMT5Template(accountData, apiEndpoint);
  } else {
    return getMT4Template(accountData, apiEndpoint);
  }
}

function getMT5Template(account: any, apiEndpoint: string): string {
  return `//+------------------------------------------------------------------+
//|                                    SentraConnector_MT5.mq5      |
//|                                          Sentra Partners        |
//|                                   https://sentrapartners.com    |
//+------------------------------------------------------------------+
#property copyright "Sentra Partners"
#property link      "https://sentrapartners.com"
#property version   "1.00"
#property description "Conector Sentra Partners - Sincronização de Conta MT5"

#include <Trade\\Trade.mqh>
#include <Trade\\PositionInfo.mqh>

//+------------------------------------------------------------------+
//| CONFIGURAÇÕES DA CONTA (INJETADAS AUTOMATICAMENTE)              |
//+------------------------------------------------------------------+
string API_KEY = "${account.api_key}";
string ACCOUNT_ID = "${account.id}";
string MT_LOGIN = "${account.account_number}";
string MT_SERVER = "${account.server}";
string API_ENDPOINT = "${apiEndpoint}";
string PLATFORM = "MT5";
string ACCOUNT_NAME = "${account.name}";
string CURRENCY = "${account.currency}";
bool IS_CENT = ${account.is_cent ? 'true' : 'false'};

//+------------------------------------------------------------------+
//| VARIÁVEIS GLOBAIS                                                |
//+------------------------------------------------------------------+
datetime g_lastSyncTime = 0;
int g_syncInterval = 300; // 5 minutos
bool g_connectionActive = false;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
    Print("🚀 Sentra Partners Connector iniciado");
    Print("📊 Conta: ", ACCOUNT_NAME);
    Print("🔐 Login: ", MT_LOGIN);
    Print("🌐 Servidor: ", MT_SERVER);
    
    // Teste inicial de conexão
    TestConnection();
    
    // Sincronização inicial
    SyncAccountData();
    
    return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
    Print("⏹️ Sentra Partners Connector finalizado");
}

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
    // Sincronização periódica
    if(TimeCurrent() - g_lastSyncTime > g_syncInterval)
    {
        SyncAccountData();
        g_lastSyncTime = TimeCurrent();
    }
}

//+------------------------------------------------------------------+
//| Trade transaction function                                       |
//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction& trans,
                       const MqlTradeRequest& request,
                       const MqlTradeResult& result)
{
    // Enviar dados da transação imediatamente
    if(trans.type == TRADE_TRANSACTION_DEAL_ADD)
    {
        SendTradeData(trans);
    }
}

//+------------------------------------------------------------------+
//| Função para testar conexão com API                              |
//+------------------------------------------------------------------+
bool TestConnection()
{
    string url = API_ENDPOINT + "/connector-test";
    string headers = "Content-Type: application/json\\r\\n";
    headers += "Authorization: Bearer " + API_KEY + "\\r\\n";
    
    string data = "{\\"account_id\\":\\"" + ACCOUNT_ID + "\\",\\"platform\\":\\"" + PLATFORM + "\\"}";
    
    char post[], result[];
    StringToCharArray(data, post, 0, StringLen(data));
    
    int res = WebRequest("POST", url, headers, 5000, post, result, headers);
    
    if(res == 200)
    {
        g_connectionActive = true;
        Print("✅ Conexão com Sentra Partners estabelecida");
        return true;
    }
    else
    {
        g_connectionActive = false;
        Print("❌ Erro de conexão com Sentra Partners. Código: ", res);
        return false;
    }
}

//+------------------------------------------------------------------+
//| Função para sincronizar dados da conta                          |
//+------------------------------------------------------------------+
void SyncAccountData()
{
    if(!g_connectionActive) return;
    
    // Coletar dados da conta
    double balance = AccountInfoDouble(ACCOUNT_BALANCE);
    double equity = AccountInfoDouble(ACCOUNT_EQUITY);
    double margin = AccountInfoDouble(ACCOUNT_MARGIN);
    double freeMargin = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
    double profit = AccountInfoDouble(ACCOUNT_PROFIT);
    
    // Ajustar para contas cent
    if(IS_CENT)
    {
        balance /= 100;
        equity /= 100;
        margin /= 100;
        freeMargin /= 100;
        profit /= 100;
    }
    
    // Preparar dados JSON
    string jsonData = "{";
    jsonData += "\\"account_id\\":\\"" + ACCOUNT_ID + "\\",";
    jsonData += "\\"mt_login\\":\\"" + MT_LOGIN + "\\",";
    jsonData += "\\"balance\\":" + DoubleToString(balance, 2) + ",";
    jsonData += "\\"equity\\":" + DoubleToString(equity, 2) + ",";
    jsonData += "\\"margin\\":" + DoubleToString(margin, 2) + ",";
    jsonData += "\\"free_margin\\":" + DoubleToString(freeMargin, 2) + ",";
    jsonData += "\\"profit\\":" + DoubleToString(profit, 2) + ",";
    jsonData += "\\"currency\\":\\"" + CURRENCY + "\\",";
    jsonData += "\\"server\\":\\"" + MT_SERVER + "\\",";
    jsonData += "\\"timestamp\\":\\"" + TimeToString(TimeCurrent()) + "\\"";
    jsonData += "}";
    
    // Enviar para API
    SendToAPI("/sync-account", jsonData);
}

//+------------------------------------------------------------------+
//| Função para enviar dados de trade                               |
//+------------------------------------------------------------------+
void SendTradeData(const MqlTradeTransaction& trans)
{
    if(!g_connectionActive) return;
    
    // Obter detalhes do deal
    ulong dealTicket = trans.deal;
    if(dealTicket == 0) return;
    
    if(!HistoryDealSelect(dealTicket)) return;
    
    string symbol = HistoryDealGetString(dealTicket, DEAL_SYMBOL);
    double volume = HistoryDealGetDouble(dealTicket, DEAL_VOLUME);
    double price = HistoryDealGetDouble(dealTicket, DEAL_PRICE);
    double profit = HistoryDealGetDouble(dealTicket, DEAL_PROFIT);
    datetime time = (datetime)HistoryDealGetInteger(dealTicket, DEAL_TIME);
    ENUM_DEAL_TYPE dealType = (ENUM_DEAL_TYPE)HistoryDealGetInteger(dealTicket, DEAL_TYPE);
    
    // Ajustar para contas cent
    if(IS_CENT)
    {
        profit /= 100;
    }
    
    string typeStr = (dealType == DEAL_TYPE_BUY) ? "BUY" : "SELL";
    
    // Preparar dados JSON
    string jsonData = "{";
    jsonData += "\\"account_id\\":\\"" + ACCOUNT_ID + "\\",";
    jsonData += "\\"deal_ticket\\":\\"" + IntegerToString(dealTicket) + "\\",";
    jsonData += "\\"symbol\\":\\"" + symbol + "\\",";
    jsonData += "\\"type\\":\\"" + typeStr + "\\",";
    jsonData += "\\"volume\\":" + DoubleToString(volume, 2) + ",";
    jsonData += "\\"price\\":" + DoubleToString(price, 5) + ",";
    jsonData += "\\"profit\\":" + DoubleToString(profit, 2) + ",";
    jsonData += "\\"time\\":\\"" + TimeToString(time) + "\\",";
    jsonData += "\\"currency\\":\\"" + CURRENCY + "\\"";
    jsonData += "}";
    
    // Enviar para API
    SendToAPI("/trade-data", jsonData);
}

//+------------------------------------------------------------------+
//| Função genérica para enviar dados para API                      |
//+------------------------------------------------------------------+
bool SendToAPI(string endpoint, string jsonData)
{
    string url = API_ENDPOINT + endpoint;
    string headers = "Content-Type: application/json\\r\\n";
    headers += "Authorization: Bearer " + API_KEY + "\\r\\n";
    
    char post[], result[];
    StringToCharArray(jsonData, post, 0, StringLen(jsonData));
    
    int res = WebRequest("POST", url, headers, 10000, post, result, headers);
    
    if(res == 200)
    {
        return true;
    }
    else
    {
        Print("❌ Erro ao enviar dados para API. Endpoint: ", endpoint, " Código: ", res);
        return false;
    }
}`;
}

function getMT4Template(account: any, apiEndpoint: string): string {
  return `//+------------------------------------------------------------------+
//|                                    SentraConnector_MT4.mq4      |
//|                                          Sentra Partners        |
//|                                   https://sentrapartners.com    |
//+------------------------------------------------------------------+
#property copyright "Sentra Partners"
#property link      "https://sentrapartners.com"
#property version   "1.00"
#property description "Conector Sentra Partners - Sincronização de Conta MT4"

//+------------------------------------------------------------------+
//| CONFIGURAÇÕES DA CONTA (INJETADAS AUTOMATICAMENTE)              |
//+------------------------------------------------------------------+
string API_KEY = "${account.api_key}";
string ACCOUNT_ID = "${account.id}";
string MT_LOGIN = "${account.account_number}";
string MT_SERVER = "${account.server}";
string API_ENDPOINT = "${apiEndpoint}";
string PLATFORM = "MT4";
string ACCOUNT_NAME = "${account.name}";
string CURRENCY = "${account.currency}";
bool IS_CENT = ${account.is_cent ? 'true' : 'false'};

//+------------------------------------------------------------------+
//| VARIÁVEIS GLOBAIS                                                |
//+------------------------------------------------------------------+
datetime g_lastSyncTime = 0;
int g_syncInterval = 300; // 5 minutos
bool g_connectionActive = false;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
{
    Print("🚀 Sentra Partners Connector MT4 iniciado");
    Print("📊 Conta: ", ACCOUNT_NAME);
    Print("🔐 Login: ", MT_LOGIN);
    
    TestConnection();
    SyncAccountData();
    
    return(0);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                |
//+------------------------------------------------------------------+
int deinit()
{
    Print("⏹️ Sentra Partners Connector MT4 finalizado");
    return(0);
}

//+------------------------------------------------------------------+
//| Expert start function                                            |
//+------------------------------------------------------------------+
int start()
{
    if(TimeCurrent() - g_lastSyncTime > g_syncInterval)
    {
        SyncAccountData();
        g_lastSyncTime = TimeCurrent();
    }
    
    return(0);
}

//+------------------------------------------------------------------+
//| Função para testar conexão                                      |
//+------------------------------------------------------------------+
bool TestConnection()
{
    g_connectionActive = true;
    Print("✅ Conexão MT4 estabelecida");
    return true;
}

//+------------------------------------------------------------------+
//| Função para sincronizar dados da conta                          |
//+------------------------------------------------------------------+
void SyncAccountData()
{
    if(!g_connectionActive) return;
    
    double balance = AccountBalance();
    double equity = AccountEquity();
    double margin = AccountMargin();
    double freeMargin = AccountFreeMargin();
    double profit = AccountProfit();
    
    if(IS_CENT)
    {
        balance /= 100;
        equity /= 100;
        margin /= 100;
        freeMargin /= 100;
        profit /= 100;
    }
    
    Print("📊 Sync - Balance: ", balance, " Equity: ", equity, " Profit: ", profit);
}`;
}