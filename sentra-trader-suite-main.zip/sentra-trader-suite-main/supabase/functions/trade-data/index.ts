import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': 'https://haoflzjojbvyhqpilpza.supabase.co',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const tradeData = await req.json();
    
    // Validate required trade data
    if (!tradeData.account_id || !tradeData.symbol || !tradeData.type) {
      return new Response(
        JSON.stringify({ error: 'Missing required trade fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get API key from Authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return new Response(
        JSON.stringify({ error: 'Invalid authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const apiKey = authHeader.replace('Bearer ', '');
    
    // Validate API key and get account
    const { data: account, error: authError } = await supabaseClient
      .from('trading_accounts')
      .select('*')
      .eq('id', tradeData.account_id)
      .eq('api_key', apiKey)
      .single();

    if (authError || !account) {
      return new Response(
        JSON.stringify({ error: 'Invalid API key or account not found' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Insert trade data
    const { error: insertError } = await supabaseClient
      .from('trades')
      .insert({
        account_id: tradeData.account_id,
        symbol: tradeData.symbol,
        trade_type: tradeData.type,
        volume: tradeData.volume,
        open_price: tradeData.price,
        close_price: tradeData.price, // For now, using same price
        profit: tradeData.profit,
        open_time: new Date(tradeData.time).toISOString(),
        close_time: new Date(tradeData.time).toISOString(), // For now, using same time
      });

    if (insertError) {
      throw insertError;
    }

    console.log(`Trade recorded for account ${tradeData.account_id}: ${tradeData.symbol} ${tradeData.type} ${tradeData.volume} lots`);

    return new Response(
      JSON.stringify({ 
        status: 'success', 
        message: 'Trade registrado com sucesso',
        recorded_at: new Date().toISOString()
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error recording trade data:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});