-- Create user roles enum
CREATE TYPE public.user_role AS ENUM ('client', 'manager', 'owner');

-- Create auth provider enum  
CREATE TYPE public.auth_provider AS ENUM ('email', 'google', 'apple');

-- Create account platform enum
CREATE TYPE public.account_platform AS ENUM ('MT4', 'MT5');

-- Create trade type enum
CREATE TYPE public.trade_type AS ENUM ('buy', 'sell');

-- Create profiles table for additional user information
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'client',
  auth_provider auth_provider NOT NULL DEFAULT 'email',
  provider_id TEXT,
  manager_id UUID REFERENCES public.profiles(id),
  timezone TEXT DEFAULT 'America/Sao_Paulo',
  language TEXT DEFAULT 'pt-BR',
  currency_display TEXT DEFAULT 'USD',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create trading accounts table
CREATE TABLE public.trading_accounts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  platform account_platform NOT NULL,
  account_number TEXT NOT NULL,
  server TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  is_cent BOOLEAN NOT NULL DEFAULT false,
  balance DECIMAL(15,2) NOT NULL DEFAULT 0,
  equity DECIMAL(15,2) NOT NULL DEFAULT 0,
  margin DECIMAL(15,2) NOT NULL DEFAULT 0,
  profit DECIMAL(15,2) NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT true,
  api_key TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(account_number, server)
);

-- Enable RLS on trading_accounts
ALTER TABLE public.trading_accounts ENABLE ROW LEVEL SECURITY;

-- Create trades table
CREATE TABLE public.trades (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.trading_accounts(id) ON DELETE CASCADE,
  symbol TEXT NOT NULL,
  trade_type trade_type NOT NULL,
  volume DECIMAL(10,4) NOT NULL,
  open_price DECIMAL(10,5) NOT NULL,
  close_price DECIMAL(10,5),
  profit DECIMAL(15,2),
  open_time TIMESTAMP WITH TIME ZONE NOT NULL,
  close_time TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on trades
ALTER TABLE public.trades ENABLE ROW LEVEL SECURITY;

-- Create account notes table
CREATE TABLE public.account_notes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID NOT NULL REFERENCES public.trading_accounts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  vm_notes TEXT,
  account_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(account_id, user_id)
);

-- Enable RLS on account_notes
ALTER TABLE public.account_notes ENABLE ROW LEVEL SECURITY;

-- Create economic events table
CREATE TABLE public.economic_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_date DATE NOT NULL,
  event_time TIME NOT NULL,
  currency TEXT NOT NULL,
  event_name TEXT NOT NULL,
  impact TEXT NOT NULL CHECK (impact IN ('low', 'medium', 'high')),
  forecast TEXT,
  previous TEXT,
  actual TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on economic_events
ALTER TABLE public.economic_events ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for profiles
CREATE POLICY "Users can view their own profile" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile" 
ON public.profiles 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Managers can view their clients' profiles
CREATE POLICY "Managers can view clients profiles" 
ON public.profiles 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles p 
    WHERE p.user_id = auth.uid() 
    AND p.role = 'manager' 
    AND public.profiles.manager_id = p.id
  )
);

-- Owners can view all profiles
CREATE POLICY "Owners can view all profiles" 
ON public.profiles 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles p 
    WHERE p.user_id = auth.uid() 
    AND p.role = 'owner'
  )
);

-- Create RLS policies for trading_accounts
CREATE POLICY "Users can view their own accounts" 
ON public.trading_accounts 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their own accounts" 
ON public.trading_accounts 
FOR ALL 
USING (auth.uid() = user_id);

-- Managers can view their clients' accounts
CREATE POLICY "Managers can view clients accounts" 
ON public.trading_accounts 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles p 
    WHERE p.user_id = auth.uid() 
    AND p.role = 'manager' 
    AND EXISTS (
      SELECT 1 FROM public.profiles client 
      WHERE client.user_id = public.trading_accounts.user_id 
      AND client.manager_id = p.id
    )
  )
);

-- Create RLS policies for trades
CREATE POLICY "Users can view their trades" 
ON public.trades 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.trading_accounts ta 
    WHERE ta.id = public.trades.account_id 
    AND ta.user_id = auth.uid()
  )
);

-- Create RLS policies for account_notes
CREATE POLICY "Users can manage their notes" 
ON public.account_notes 
FOR ALL 
USING (auth.uid() = user_id);

-- Create RLS policies for economic_events (public read)
CREATE POLICY "Everyone can view economic events" 
ON public.economic_events 
FOR SELECT 
USING (true);

-- Create function to update updated_at column
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_trading_accounts_updated_at
  BEFORE UPDATE ON public.trading_accounts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_account_notes_updated_at
  BEFORE UPDATE ON public.account_notes
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, name, auth_provider)
  VALUES (
    NEW.id, 
    COALESCE(NEW.raw_user_meta_data->>'name', NEW.email),
    CASE 
      WHEN NEW.app_metadata->>'provider' = 'google' THEN 'google'::auth_provider
      WHEN NEW.app_metadata->>'provider' = 'apple' THEN 'apple'::auth_provider
      ELSE 'email'::auth_provider
    END
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Trigger to create profile when user signs up
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Insert demo economic events
INSERT INTO public.economic_events (event_date, event_time, currency, event_name, impact, forecast, previous) VALUES
  (CURRENT_DATE, '14:30:00', 'USD', 'Fed Interest Rate Decision', 'high', '5.25%', '5.00%'),
  (CURRENT_DATE + 1, '09:30:00', 'EUR', 'ECB Monetary Policy Statement', 'high', '-', '4.50%'),
  (CURRENT_DATE + 1, '13:30:00', 'USD', 'Non-Farm Payrolls', 'high', '180K', '175K'),
  (CURRENT_DATE + 2, '08:30:00', 'GBP', 'GDP Growth Rate', 'medium', '0.2%', '0.1%'),
  (CURRENT_DATE + 2, '21:30:00', 'JPY', 'BOJ Interest Rate Decision', 'high', '-0.10%', '-0.10%');