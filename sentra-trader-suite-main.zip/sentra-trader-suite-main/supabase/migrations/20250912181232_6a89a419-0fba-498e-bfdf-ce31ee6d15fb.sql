-- Corrigir função de novos usuários
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (user_id, name, role, auth_provider, timezone, language, currency_display)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    'client',
    COALESCE(NEW.raw_app_meta_data->>'provider', 'email'),
    'America/Sao_Paulo',
    'pt',
    'BRL'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recriar trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Tabela para atualizações de trading em tempo real
CREATE TABLE IF NOT EXISTS trading_updates (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID REFERENCES trading_accounts(id) ON DELETE CASCADE,
  api_key TEXT NOT NULL,
  balance DECIMAL(15,2),
  equity DECIMAL(15,2),
  profit DECIMAL(15,2),
  margin DECIMAL(15,2),
  margin_free DECIMAL(15,2),
  margin_level DECIMAL(8,2),
  open_trades_count INTEGER DEFAULT 0,
  last_update_source TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela para histórico de trades
CREATE TABLE IF NOT EXISTS trade_history (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID REFERENCES trading_accounts(id) ON DELETE CASCADE,
  ticket BIGINT NOT NULL,
  symbol TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('BUY', 'SELL')),
  volume DECIMAL(10,2),
  open_time TIMESTAMP WITH TIME ZONE,
  close_time TIMESTAMP WITH TIME ZONE,
  open_price DECIMAL(10,5),
  close_price DECIMAL(10,5),
  profit DECIMAL(15,2),
  commission DECIMAL(15,2),
  swap DECIMAL(15,2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(account_id, ticket)
);

-- Tabela para posições abertas
CREATE TABLE IF NOT EXISTS open_positions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  account_id UUID REFERENCES trading_accounts(id) ON DELETE CASCADE,
  ticket BIGINT NOT NULL,
  symbol TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('BUY', 'SELL')),
  volume DECIMAL(10,2),
  open_time TIMESTAMP WITH TIME ZONE,
  open_price DECIMAL(10,5),
  current_price DECIMAL(10,5),
  profit DECIMAL(15,2),
  commission DECIMAL(15,2),
  swap DECIMAL(15,2),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(account_id, ticket)
);

-- Tabela para eventos do ForexFactory
CREATE TABLE IF NOT EXISTS forex_factory_events (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  ff_event_id TEXT UNIQUE,
  title TEXT NOT NULL,
  country TEXT NOT NULL,
  currency TEXT NOT NULL,
  event_date DATE NOT NULL,
  event_time TIME NOT NULL,
  impact TEXT CHECK (impact IN ('Low', 'Medium', 'High')),
  forecast TEXT,
  previous TEXT,
  actual TEXT,
  description TEXT,
  source_url TEXT,
  last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela para taxas de câmbio em tempo real
CREATE TABLE IF NOT EXISTS exchange_rates (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  base_currency TEXT NOT NULL DEFAULT 'USD',
  target_currency TEXT NOT NULL,
  rate DECIMAL(10,6) NOT NULL,
  source TEXT DEFAULT 'exchangerate-api',
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(base_currency, target_currency)
);

-- Função RPC para autenticação do conector
CREATE OR REPLACE FUNCTION authenticate_connector(
  p_account_number TEXT,
  p_investor_password TEXT,
  p_user_id UUID
)
RETURNS JSON AS $$
DECLARE
  account_record RECORD;
  api_key_generated TEXT;
BEGIN
  -- Verificar se a conta existe e pertence ao usuário
  SELECT * INTO account_record 
  FROM trading_accounts 
  WHERE account_number = p_account_number 
    AND user_id = p_user_id 
    AND active = true;
  
  IF NOT FOUND THEN
    RETURN json_build_object('message', 'Account not found or inactive');
  END IF;
  
  -- Gerar API key única
  api_key_generated := encode(gen_random_bytes(32), 'hex');
  
  -- Atualizar a conta com a nova API key
  UPDATE trading_accounts 
  SET api_key = api_key_generated,
      api_key_created_at = NOW(),
      updated_at = NOW()
  WHERE id = account_record.id;
  
  RETURN json_build_object(
    'api_key', api_key_generated,
    'account_id', account_record.id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Habilitar RLS
ALTER TABLE trading_updates ENABLE ROW LEVEL SECURITY;
ALTER TABLE trade_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE open_positions ENABLE ROW LEVEL SECURITY;
ALTER TABLE forex_factory_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE exchange_rates ENABLE ROW LEVEL SECURITY;

-- Políticas RLS
CREATE POLICY "Users can view their own trading updates" ON trading_updates
  FOR SELECT USING (
    account_id IN (
      SELECT id FROM trading_accounts WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Connectors can insert trading updates" ON trading_updates
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM trading_accounts 
      WHERE id = account_id AND api_key = trading_updates.api_key
    )
  );

CREATE POLICY "Users can view their trade history" ON trade_history
  FOR SELECT USING (
    account_id IN (
      SELECT id FROM trading_accounts WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Connectors can manage trade history" ON trade_history
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM trading_accounts 
      WHERE id = account_id AND api_key IS NOT NULL
    )
  );

CREATE POLICY "Users can view their open positions" ON open_positions
  FOR SELECT USING (
    account_id IN (
      SELECT id FROM trading_accounts WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Connectors can manage open positions" ON open_positions
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM trading_accounts 
      WHERE id = account_id AND api_key IS NOT NULL
    )
  );

CREATE POLICY "Everyone can read forex factory events" ON forex_factory_events FOR SELECT USING (true);
CREATE POLICY "Everyone can read exchange rates" ON exchange_rates FOR SELECT USING (true);