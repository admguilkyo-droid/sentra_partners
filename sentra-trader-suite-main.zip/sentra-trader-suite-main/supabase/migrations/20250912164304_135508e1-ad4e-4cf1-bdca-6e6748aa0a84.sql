-- Fix RLS infinite recursion by creating security definer functions
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS TEXT AS $$
  SELECT role::text FROM public.profiles WHERE user_id = auth.uid();
$$ LANGUAGE SQL SECURITY DEFINER STABLE SET search_path = public;

CREATE OR REPLACE FUNCTION public.is_manager()
RETURNS BOOLEAN AS $$
  SELECT EXISTS(
    SELECT 1 FROM public.profiles 
    WHERE user_id = auth.uid() AND role = 'manager'::user_role
  );
$$ LANGUAGE SQL SECURITY DEFINER STABLE SET search_path = public;

CREATE OR REPLACE FUNCTION public.is_owner()
RETURNS BOOLEAN AS $$
  SELECT EXISTS(
    SELECT 1 FROM public.profiles 
    WHERE user_id = auth.uid() AND role = 'owner'::user_role
  );
$$ LANGUAGE SQL SECURITY DEFINER STABLE SET search_path = public;

CREATE OR REPLACE FUNCTION public.get_manager_id()
RETURNS UUID AS $$
  SELECT id FROM public.profiles WHERE user_id = auth.uid() AND role = 'manager'::user_role;
$$ LANGUAGE SQL SECURITY DEFINER STABLE SET search_path = public;

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Managers can view clients profiles" ON public.profiles;
DROP POLICY IF EXISTS "Owners can view all profiles" ON public.profiles;

-- Create new policies using security definer functions
CREATE POLICY "Managers can view clients profiles"
ON public.profiles
FOR SELECT
USING (
  public.is_manager() AND 
  manager_id = public.get_manager_id()
);

CREATE POLICY "Owners can view all profiles"
ON public.profiles
FOR ALL
USING (public.is_owner());

-- Add missing RLS policies for trades table
CREATE POLICY "Users can insert their own trades"
ON public.trades
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM trading_accounts ta
    WHERE ta.id = trades.account_id AND ta.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update their own trades"
ON public.trades
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM trading_accounts ta
    WHERE ta.id = trades.account_id AND ta.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete their own trades"
ON public.trades
FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM trading_accounts ta
    WHERE ta.id = trades.account_id AND ta.user_id = auth.uid()
  )
);

-- Add API key rotation fields to trading_accounts
ALTER TABLE public.trading_accounts 
ADD COLUMN IF NOT EXISTS api_key_created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
ADD COLUMN IF NOT EXISTS api_key_expires_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS api_key_encrypted BOOLEAN DEFAULT false;

-- Create function to rotate API keys
CREATE OR REPLACE FUNCTION public.rotate_api_key(account_uuid UUID)
RETURNS TEXT AS $$
DECLARE
    new_key TEXT;
BEGIN
    -- Generate new API key
    new_key := encode(gen_random_bytes(32), 'base64');
    
    -- Update the account
    UPDATE public.trading_accounts 
    SET 
        api_key = new_key,
        api_key_created_at = now(),
        api_key_expires_at = now() + interval '90 days',
        updated_at = now()
    WHERE id = account_uuid AND user_id = auth.uid();
    
    RETURN new_key;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;