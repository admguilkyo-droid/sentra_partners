-- Corrigir warnings de segurança das funções
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (user_id, name, role, auth_provider, timezone, language, currency_display)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    'client',
    COALESCE(NEW.raw_app_meta_data->>'provider', 'email'),
    'America/Sao_Paulo',
    'pt',
    'BRL'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Corrigir função de autenticação do conector
CREATE OR REPLACE FUNCTION authenticate_connector(
  p_account_number TEXT,
  p_investor_password TEXT,
  p_user_id UUID
)
RETURNS JSON AS $$
DECLARE
  account_record RECORD;
  api_key_generated TEXT;
BEGIN
  -- Verificar se a conta existe e pertence ao usuário
  SELECT * INTO account_record 
  FROM trading_accounts 
  WHERE account_number = p_account_number 
    AND user_id = p_user_id 
    AND active = true;
  
  IF NOT FOUND THEN
    RETURN json_build_object('message', 'Account not found or inactive');
  END IF;
  
  -- Gerar API key única
  api_key_generated := encode(gen_random_bytes(32), 'hex');
  
  -- Atualizar a conta com a nova API key
  UPDATE trading_accounts 
  SET api_key = api_key_generated,
      api_key_created_at = NOW(),
      updated_at = NOW()
  WHERE id = account_record.id;
  
  RETURN json_build_object(
    'api_key', api_key_generated,
    'account_id', account_record.id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;