-- Fix handle_new_user to use correct columns from auth.users
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, name, auth_provider)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', NEW.email),
    CASE 
      WHEN COALESCE(NEW.raw_app_meta_data->>'provider','email') = 'google' THEN 'google'::auth_provider
      WHEN COALESCE(NEW.raw_app_meta_data->>'provider','email') = 'apple' THEN 'apple'::auth_provider
      ELSE 'email'::auth_provider
    END
  );
  RETURN NEW;
END;
$$;